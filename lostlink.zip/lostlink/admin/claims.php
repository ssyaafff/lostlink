<?php

session_start();
require_once "../config.php";

// =====================================================
// SEMAK ADMIN
// =====================================================

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['role'] != 'admin') {
    header("Location: ../dashboard.php");
    exit();
}


// =====================================================
// PROSES APPROVE / REJECT
// =====================================================

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $claim_id = intval($_POST['claim_id']);
    $action = $_POST['action'];

    // =========================
    // APPROVE CLAIM
    // =========================

    if ($action == "approve") {

        // Dapatkan item_id dan status item
        $stmt = $mysqli->prepare("
            SELECT item_id
            FROM claims
            WHERE claim_id = ?
        ");

        $stmt->bind_param("i", $claim_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {

            $claim = $result->fetch_assoc();
            $item_id = $claim['item_id'];

            // Semak status barang
            $stmt2 = $mysqli->prepare("
                SELECT status
                FROM items
                WHERE item_id = ?
            ");

            $stmt2->bind_param("i", $item_id);
            $stmt2->execute();
            $result2 = $stmt2->get_result();

            if ($result2->num_rows > 0) {

                $item = $result2->fetch_assoc();

                // Hanya boleh approve jika barang belum claimed/closed
                if ($item['status'] != "Claimed" && $item['status'] != "Closed") {

                    // Approve claim
                    $stmt3 = $mysqli->prepare("
                        UPDATE claims
                        SET status = 'Approved'
                        WHERE claim_id = ?
                    ");

                    $stmt3->bind_param("i", $claim_id);
                    $stmt3->execute();

                    // Tukar status barang kepada Claimed
                    $stmt4 = $mysqli->prepare("
                        UPDATE items
                        SET status = 'Claimed'
                        WHERE item_id = ?
                    ");

                    $stmt4->bind_param("i", $item_id);
                    $stmt4->execute();

                    // Reject claim lain untuk barang yang sama
                    $stmt5 = $mysqli->prepare("
                        UPDATE claims
                        SET status = 'Rejected'
                        WHERE item_id = ?
                        AND claim_id != ?
                        AND status = 'Pending'
                    ");

                    $stmt5->bind_param("ii", $item_id, $claim_id);
                    $stmt5->execute();

                    header("Location: claims.php?success=approved");
                    exit();

                } else {

                    header("Location: claims.php?error=already_claimed");
                    exit();
                }
            }
        }
    }


    // =========================
    // REJECT CLAIM
    // =========================

    if ($action == "reject") {

        $stmt = $mysqli->prepare("
            UPDATE claims
            SET status = 'Rejected'
            WHERE claim_id = ?
        ");

        $stmt->bind_param("i", $claim_id);
        $stmt->execute();

        header("Location: claims.php?success=rejected");
        exit();
    }
}


// =====================================================
// SEARCH & FILTER
// =====================================================

$search = "";

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

$status_filter = "";

if (isset($_GET['status'])) {
    $status_filter = $_GET['status'];
}


// =====================================================
// QUERY CLAIMS
// =====================================================

$sql = "
    SELECT
        claims.claim_id,
        claims.item_id,
        claims.reason,
        claims.proof_image,
        claims.status AS claim_status,
        claims.created_at,

        items.item_name,
        items.category,
        items.location,
        items.status AS item_status,

        users.name AS claimant_name,
        users.matric_no

    FROM claims

    INNER JOIN items
        ON claims.item_id = items.item_id

    INNER JOIN users
        ON claims.user_id = users.user_id

    WHERE 1=1
";

$params = array();
$types = "";


// Search
if ($search != "") {

    $sql .= "
        AND (
            items.item_name LIKE ?
            OR items.category LIKE ?
            OR users.name LIKE ?
            OR users.matric_no LIKE ?
        )
    ";

    $search_value = "%" . $search . "%";

    $params[] = $search_value;
    $params[] = $search_value;
    $params[] = $search_value;
    $params[] = $search_value;

    $types .= "ssss";
}


// Filter status
if ($status_filter != "") {

    $sql .= " AND claims.status = ? ";

    $params[] = $status_filter;
    $types .= "s";
}


$sql .= " ORDER BY claims.created_at DESC";


// =====================================================
// PREPARED STATEMENT
// =====================================================

$stmt = $mysqli->prepare($sql);

if (count($params) > 0) {

    $bind_names = array();
    $bind_names[] = $types;

    for ($i = 0; $i < count($params); $i++) {
        $bind_names[] = &$params[$i];
    }

    call_user_func_array(
        array($stmt, "bind_param"),
        $bind_names
    );
}

$stmt->execute();

$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="ms">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pengurusan Tuntutan - LostLink</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f7fb;
            color: #1f2937;
        }

        /* =========================
           NAVBAR
        ========================= */

        .navbar {
            width: 100%;
            min-height: 75px;
            background: white;
            display: flex;
            align-items: center;
            padding: 0 6%;
            border-bottom: 1px solid #e5e7eb;
        }

        .logo {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }

        .logo img {
            width: 145px;
            height: auto;
            display: block;
        }

        .nav-links {
            margin-left: auto;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
            white-space: nowrap;
        }

        .nav-links a {
            text-decoration: none;
            color: #374151;
            font-size: 14px;
            font-weight: 600;
        }

        .nav-links a:hover {
            color: #2563eb;
        }

        .logout {
            color: #dc2626 !important;
        }

        /* =========================
           CONTAINER
        ========================= */

        .container {
            width: 90%;
            max-width: 1400px;
            margin: 35px auto;
        }

        .page-title {
            margin-bottom: 25px;
        }

        .page-title h1 {
            font-size: 28px;
            color: #111827;
            margin-bottom: 7px;
        }

        .page-title p {
            color: #6b7280;
            font-size: 14px;
        }

        /* =========================
           ALERT
        ========================= */

        .alert {
            padding: 14px 18px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 600;
        }

        .success {
            background: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        /* =========================
           FILTER
        ========================= */

        .filter-box {
            background: white;
            padding: 20px;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            margin-bottom: 25px;
        }

        .filter-form {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .filter-form input,
        .filter-form select {
            height: 42px;
            padding: 0 12px;
            border: 1px solid #d1d5db;
            border-radius: 7px;
            font-size: 14px;
            outline: none;
        }

        .filter-form input {
            flex: 1;
            min-width: 230px;
        }

        .filter-form input:focus,
        .filter-form select:focus {
            border-color: #2563eb;
        }

        .btn-search {
            background: #2563eb;
            color: white;
            border: none;
            padding: 0 22px;
            border-radius: 7px;
            cursor: pointer;
            font-weight: 600;
        }

        .btn-search:hover {
            background: #1d4ed8;
        }

        /* =========================
           TABLE
        ========================= */

        .table-box {
            background: white;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1050px;
        }

        th {
            background: #f8fafc;
            padding: 15px;
            text-align: left;
            font-size: 13px;
            color: #475569;
            border-bottom: 1px solid #e5e7eb;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: top;
            font-size: 13px;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover {
            background: #fafafa;
        }

        .item-name {
            font-weight: 700;
            color: #111827;
            margin-bottom: 5px;
        }

        .small-text {
            color: #6b7280;
            font-size: 12px;
            margin-top: 3px;
        }

        /* =========================
           BADGES
        ========================= */

        .badge {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
        }

        .pending {
            background: #fef3c7;
            color: #92400e;
        }

        .approved {
            background: #dcfce7;
            color: #166534;
        }

        .rejected {
            background: #fee2e2;
            color: #991b1b;
        }

        .claimed {
            background: #dbeafe;
            color: #1e40af;
        }

        .closed {
            background: #e5e7eb;
            color: #374151;
        }

        /* =========================
           PROOF IMAGE
        ========================= */

        .proof-image {
            width: 70px;
            height: 70px;
            object-fit: cover;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            display: block;
        }

        .no-proof {
            color: #9ca3af;
            font-size: 12px;
        }

        /* =========================
           BUTTON
        ========================= */

        .action-buttons {
            display: flex;
            gap: 7px;
            flex-wrap: wrap;
        }

        .btn {
            border: none;
            border-radius: 6px;
            padding: 8px 11px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .btn-approve {
            background: #16a34a;
            color: white;
        }

        .btn-approve:hover {
            background: #15803d;
        }

        .btn-reject {
            background: #dc2626;
            color: white;
        }

        .btn-reject:hover {
            background: #b91c1c;
        }

        .btn-view {
            background: #eff6ff;
            color: #1d4ed8;
        }

        .btn-view:hover {
            background: #dbeafe;
        }

        /* =========================
           EMPTY
        ========================= */

        .empty {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }

        .empty h3 {
            color: #374151;
            margin-bottom: 8px;
        }

        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 800px) {

            .navbar {
                padding: 15px 5%;
                flex-direction: column;
                gap: 12px;
            }

            .nav-links {
                margin-left: 0;
                justify-content: center;
                flex-wrap: wrap;
            }

            .container {
                width: 94%;
                margin-top: 25px;
            }

            .page-title h1 {
                font-size: 24px;
            }

            .filter-form {
                flex-direction: column;
            }

            .filter-form input {
                width: 100%;
            }

            .filter-form select,
            .btn-search {
                width: 100%;
                height: 42px;
            }
        }

    </style>

</head>

<body>


<!-- =====================================================
     NAVBAR
===================================================== -->

<div class="navbar">

    <div class="logo">
        <a href="dashboard.php">
            <img src="../assets/lostlink-logo.png" alt="LostLink Logo">
        </a>
    </div>

    <div class="nav-links">

        <a href="dashboard.php">Dashboard</a>

        <a href="reports.php">Laporan</a>

        <a href="claims.php">Tuntutan</a>

        <a href="users.php">Pengguna</a>

        <a href="../logout.php" class="logout">Log Keluar</a>

    </div>

</div>


<!-- =====================================================
     CONTENT
===================================================== -->

<div class="container">

    <div class="page-title">

        <h1>Pengurusan Tuntutan</h1>

        <p>
            Semak dan urus tuntutan barang yang dibuat oleh pelajar.
        </p>

    </div>


    <!-- SUCCESS MESSAGE -->

    <?php if (isset($_GET['success'])) { ?>

        <?php if ($_GET['success'] == "approved") { ?>

            <div class="alert success">
                Tuntutan telah diluluskan. Status barang telah ditukar kepada Claimed.
            </div>

        <?php } ?>

        <?php if ($_GET['success'] == "rejected") { ?>

            <div class="alert success">
                Tuntutan telah ditolak.
            </div>

        <?php } ?>

    <?php } ?>


    <!-- ERROR MESSAGE -->

    <?php if (isset($_GET['error'])) { ?>

        <?php if ($_GET['error'] == "already_claimed") { ?>

            <div class="alert error">
                Tuntutan tidak boleh diluluskan kerana barang tersebut telah dituntut atau ditutup.
            </div>

        <?php } ?>

    <?php } ?>


    <!-- =================================================
         FILTER
    ================================================== -->

    <div class="filter-box">

        <form method="GET" class="filter-form">

            <input
                type="text"
                name="search"
                placeholder="Cari nama barang, kategori atau pelajar..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <select name="status">

                <option value="">Semua Status</option>

                <option value="Pending"
                    <?php
                    if ($status_filter == "Pending") {
                        echo "selected";
                    }
                    ?>
                >
                    Pending
                </option>

                <option value="Approved"
                    <?php
                    if ($status_filter == "Approved") {
                        echo "selected";
                    }
                    ?>
                >
                    Approved
                </option>

                <option value="Rejected"
                    <?php
                    if ($status_filter == "Rejected") {
                        echo "selected";
                    }
                    ?>
                >
                    Rejected
                </option>

            </select>

            <button type="submit" class="btn-search">
                Cari
            </button>

        </form>

    </div>


    <!-- =================================================
         CLAIM TABLE
    ================================================== -->

    <div class="table-box">

        <?php if ($result->num_rows > 0) { ?>

            <table>

                <thead>

                    <tr>

                        <th>Barang</th>

                        <th>Penuntut</th>

                        <th>Sebab Tuntutan</th>

                        <th>Bukti</th>

                        <th>Status</th>

                        <th>Tarikh</th>

                        <th>Tindakan</th>

                    </tr>

                </thead>

                <tbody>

                <?php while ($row = $result->fetch_assoc()) { ?>

                    <tr>

                        <!-- BARANG -->

                        <td>

                            <div class="item-name">

                                <?php
                                echo htmlspecialchars($row['item_name']);
                                ?>

                            </div>

                            <div class="small-text">

                                Kategori:
                                <?php
                                echo htmlspecialchars($row['category']);
                                ?>

                            </div>

                            <div class="small-text">

                                Lokasi:
                                <?php
                                echo htmlspecialchars($row['location']);
                                ?>

                            </div>

                        </td>


                        <!-- PENUNTUT -->

                        <td>

                            <strong>
                                <?php
                                echo htmlspecialchars($row['claimant_name']);
                                ?>
                            </strong>

                            <div class="small-text">

                                <?php
                                echo htmlspecialchars($row['matric_no']);
                                ?>

                            </div>

                        </td>


                        <!-- REASON -->

                        <td>

                            <?php
                            echo nl2br(
                                htmlspecialchars($row['reason'])
                            );
                            ?>

                        </td>


                        <!-- PROOF -->

                        <td>

                            <?php if (!empty($row['proof_image'])) { ?>

                                <a
                                    href="../uploads/claims/<?php echo htmlspecialchars($row['proof_image']); ?>"
                                    target="_blank"
                                >

                                    <img
                                        src="../uploads/claims/<?php echo htmlspecialchars($row['proof_image']); ?>"
                                        class="proof-image"
                                        alt="Bukti tuntutan"
                                    >

                                </a>

                            <?php } else { ?>

                                <span class="no-proof">
                                    Tiada bukti
                                </span>

                            <?php } ?>

                        </td>


                        <!-- STATUS -->

                        <td>

                            <?php

                            if ($row['claim_status'] == "Pending") {

                                echo '<span class="badge pending">Pending</span>';

                            } elseif ($row['claim_status'] == "Approved") {

                                echo '<span class="badge approved">Approved</span>';

                            } elseif ($row['claim_status'] == "Rejected") {

                                echo '<span class="badge rejected">Rejected</span>';

                            }

                            ?>

                            <div class="small-text">

                                Barang:
                                
                                <?php

                                if ($row['item_status'] == "Claimed") {

                                    echo '<span class="badge claimed">Claimed</span>';

                                } elseif ($row['item_status'] == "Closed") {

                                    echo '<span class="badge closed">Closed</span>';

                                } elseif ($row['item_status'] == "Found") {

                                    echo '<span class="badge approved">Found</span>';

                                } else {

                                    echo '<span class="badge pending">Pending</span>';

                                }

                                ?>

                            </div>

                        </td>


                        <!-- DATE -->

                        <td>

                            <?php

                            echo date(
                                "d/m/Y H:i",
                                strtotime($row['created_at'])
                            );

                            ?>

                        </td>


                        <!-- ACTION -->

                        <td>

                            <div class="action-buttons">

                                <a
                                    href="../item_details.php?id=<?php echo $row['item_id']; ?>"
                                    class="btn btn-view"
                                >
                                    Lihat
                                </a>


                                <?php if ($row['claim_status'] == "Pending" && $row['item_status'] != "Claimed" && $row['item_status'] != "Closed") { ?>

                                    <form method="POST">

                                        <input
                                            type="hidden"
                                            name="claim_id"
                                            value="<?php echo $row['claim_id']; ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="approve"
                                        >

                                        <button
                                            type="submit"
                                            class="btn btn-approve"
                                            onclick="return confirm('Luluskan tuntutan ini?');"
                                        >
                                            Lulus
                                        </button>

                                    </form>


                                    <form method="POST">

                                        <input
                                            type="hidden"
                                            name="claim_id"
                                            value="<?php echo $row['claim_id']; ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="reject"
                                        >

                                        <button
                                            type="submit"
                                            class="btn btn-reject"
                                            onclick="return confirm('Tolak tuntutan ini?');"
                                        >
                                            Tolak
                                        </button>

                                    </form>

                                <?php } ?>

                            </div>

                        </td>

                    </tr>

                <?php } ?>

                </tbody>

            </table>

        <?php } else { ?>

            <div class="empty">

                <h3>Tiada Tuntutan</h3>

                <p>
                    Tiada tuntutan yang sepadan dengan carian atau filter anda.
                </p>

            </div>

        <?php } ?>

    </div>

</div>

</body>
</html>