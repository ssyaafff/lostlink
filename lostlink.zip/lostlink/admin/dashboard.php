<?php

session_start();
require_once "../config.php";


// =====================================================
// SEMAK LOGIN ADMIN
// =====================================================

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$admin_name = $_SESSION['name'];


// =====================================================
// STATISTIK
// =====================================================

// Jumlah pengguna
$user_query = "
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'student'
";

$user_result = $mysqli->query($user_query);
$user_data = $user_result->fetch_assoc();
$total_users = $user_data['total'];


// Jumlah laporan
$item_query = "
    SELECT COUNT(*) AS total
    FROM items
";

$item_result = $mysqli->query($item_query);
$item_data = $item_result->fetch_assoc();
$total_items = $item_data['total'];


// Jumlah barang hilang
$lost_query = "
    SELECT COUNT(*) AS total
    FROM items
    WHERE item_type = 'Lost'
";

$lost_result = $mysqli->query($lost_query);
$lost_data = $lost_result->fetch_assoc();
$total_lost = $lost_data['total'];


// Jumlah barang dijumpai
$found_query = "
    SELECT COUNT(*) AS total
    FROM items
    WHERE item_type = 'Found'
";

$found_result = $mysqli->query($found_query);
$found_data = $found_result->fetch_assoc();
$total_found = $found_data['total'];


// Jumlah tuntutan pending
$claim_query = "
    SELECT COUNT(*) AS total
    FROM claims
    WHERE status = 'Pending'
";

$claim_result = $mysqli->query($claim_query);
$claim_data = $claim_result->fetch_assoc();
$total_pending_claims = $claim_data['total'];


// =====================================================
// LAPORAN TERKINI
// =====================================================

$recent_items_query = "
    SELECT items.*, users.name
    FROM items
    INNER JOIN users
        ON items.user_id = users.user_id
    ORDER BY items.created_at DESC
    LIMIT 5
";

$recent_items_result = $mysqli->query($recent_items_query);


// =====================================================
// TUNTUTAN TERKINI
// =====================================================

$recent_claims_query = "
    SELECT
        claims.*,
        items.item_name,
        users.name
    FROM claims
    INNER JOIN items
        ON claims.item_id = items.item_id
    INNER JOIN users
        ON claims.user_id = users.user_id
    ORDER BY claims.created_at DESC
    LIMIT 5
";

$recent_claims_result = $mysqli->query($recent_claims_query);

?>

<!DOCTYPE html>
<html lang="ms">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard - LostLink</title>


    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }


        body {
            font-family: Arial, sans-serif;
            background: #f5f8fc;
            color: #1f2937;
        }


        /* =====================================================
           NAVBAR
        ===================================================== */

        .navbar {
            width: 100%;
            min-height: 75px;
            background: white;
            display: flex;
            align-items: center;
            padding: 0 6%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }


        .logo {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }


        .logo img {
            width: 150px;
            height: auto;
            display: block;
        }


        .nav-links {
            margin-left: auto;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
            white-space: nowrap;
        }


        .nav-links a {
            text-decoration: none;
            color: #374151;
            font-size: 14px;
            font-weight: 600;
        }


        .nav-links a:hover {
            color: #2563eb;
        }


        .logout {
            background: #ef4444;
            color: white !important;
            padding: 9px 15px;
            border-radius: 7px;
        }


        .logout:hover {
            background: #dc2626 !important;
        }


        /* =====================================================
           CONTAINER
        ===================================================== */

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
        }


        /* =====================================================
           WELCOME
        ===================================================== */

        .welcome {
            background: linear-gradient(
                135deg,
                #2563eb,
                #1d4ed8
            );

            color: white;

            padding: 30px;

            border-radius: 18px;

            margin-bottom: 30px;

            box-shadow: 0 5px 20px rgba(37,99,235,0.18);
        }


        .welcome h1 {
            font-size: 28px;
            margin-bottom: 8px;
        }


        .welcome p {
            opacity: 0.9;
            line-height: 1.6;
        }


        /* =====================================================
           STATISTICS
        ===================================================== */

        .stats {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 18px;
            margin-bottom: 35px;
        }


        .stat-card {
            background: white;
            padding: 22px;
            border-radius: 14px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }


        .stat-title {
            font-size: 13px;
            color: #64748b;
            margin-bottom: 10px;
        }


        .stat-number {
            font-size: 30px;
            font-weight: bold;
            color: #1e3a8a;
        }


        .stat-card.blue {
            border-left: 5px solid #2563eb;
        }


        .stat-card.red {
            border-left: 5px solid #ef4444;
        }


        .stat-card.green {
            border-left: 5px solid #22c55e;
        }


        .stat-card.orange {
            border-left: 5px solid #f59e0b;
        }


        .stat-card.purple {
            border-left: 5px solid #8b5cf6;
        }


        /* =====================================================
           SECTION
        ===================================================== */

        .section {
            background: white;
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }


        .section-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }


        .section-header h2 {
            font-size: 20px;
            color: #111827;
        }


        .view-all {
            text-decoration: none;
            color: #2563eb;
            font-size: 14px;
            font-weight: bold;
        }


        .view-all:hover {
            text-decoration: underline;
        }


        /* =====================================================
           TABLE
        ===================================================== */

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }


        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 700px;
        }


        th {
            background: #f8fafc;
            color: #64748b;
            font-size: 13px;
            text-align: left;
            padding: 13px;
            border-bottom: 1px solid #e5e7eb;
        }


        td {
            padding: 14px 13px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 14px;
        }


        tr:last-child td {
            border-bottom: none;
        }


        .item-name {
            font-weight: bold;
            color: #1f2937;
        }


        .type-badge {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: bold;
        }


        .type-lost {
            background: #fee2e2;
            color: #b91c1c;
        }


        .type-found {
            background: #dcfce7;
            color: #15803d;
        }


        .status-badge {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: bold;
        }


        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }


        .status-found {
            background: #dcfce7;
            color: #166534;
        }


        .status-claimed {
            background: #dbeafe;
            color: #1d4ed8;
        }


        .status-closed {
            background: #e5e7eb;
            color: #4b5563;
        }


        .status-approved {
            background: #dcfce7;
            color: #166534;
        }


        .status-rejected {
            background: #fee2e2;
            color: #b91c1c;
        }


        /* =====================================================
           EMPTY
        ===================================================== */

        .empty {
            text-align: center;
            padding: 30px;
            color: #94a3b8;
        }


        /* =====================================================
           QUICK ACTION
        ===================================================== */

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }


        .quick-card {
            display: block;
            text-decoration: none;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 20px;
            border-radius: 12px;
            transition: 0.2s;
        }


        .quick-card:hover {
            border-color: #2563eb;
            background: #eff6ff;
        }


        .quick-card h3 {
            color: #1e3a8a;
            font-size: 16px;
            margin-bottom: 6px;
        }


        .quick-card p {
            color: #64748b;
            font-size: 13px;
            line-height: 1.5;
        }


        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 1000px) {

            .stats {
                grid-template-columns: repeat(3, 1fr);
            }

        }


        @media (max-width: 750px) {

            .navbar {
                padding: 15px 5%;
                flex-direction: column;
                gap: 15px;
            }


            .nav-links {
                margin-left: 0;
                justify-content: center;
                flex-wrap: wrap;
                gap: 12px;
            }


            .stats {
                grid-template-columns: repeat(2, 1fr);
            }


            .quick-actions {
                grid-template-columns: 1fr;
            }

        }


        @media (max-width: 500px) {

            .container {
                width: 94%;
                margin: 25px auto;
            }


            .stats {
                grid-template-columns: 1fr;
            }


            .welcome {
                padding: 22px;
            }


            .welcome h1 {
                font-size: 23px;
            }


            .section {
                padding: 18px;
            }

        }

    </style>

</head>


<body>


    <!-- =====================================================
         NAVBAR
    ===================================================== -->

    <nav class="navbar">

        <a href="dashboard.php" class="logo">

            <img
                src="../assets/lostlink-logo.png"
                alt="LostLink Logo"
            >

        </a>


        <div class="nav-links">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="reports.php">
                Laporan
            </a>

            <a href="claims.php">
                Tuntutan
            </a>

            <a href="users.php">
                Pengguna
            </a>

            <a href="../logout.php" class="logout">
                Log Keluar
            </a>

        </div>

    </nav>


    <!-- =====================================================
         MAIN
    ===================================================== -->

    <div class="container">


        <!-- WELCOME -->

        <div class="welcome">

            <h1>
                Selamat Datang, Admin <?php echo htmlspecialchars($admin_name); ?>
            </h1>

            <p>
                Urus dan pantau laporan barang hilang,
                barang dijumpai serta tuntutan pelajar
                melalui sistem LostLink.
            </p>

        </div>


        <!-- =================================================
             STATISTICS
        ================================================= -->

        <div class="stats">


            <div class="stat-card blue">

                <div class="stat-title">
                    Jumlah Pelajar
                </div>

                <div class="stat-number">
                    <?php echo $total_users; ?>
                </div>

            </div>


            <div class="stat-card purple">

                <div class="stat-title">
                    Jumlah Laporan
                </div>

                <div class="stat-number">
                    <?php echo $total_items; ?>
                </div>

            </div>


            <div class="stat-card red">

                <div class="stat-title">
                    Barang Hilang
                </div>

                <div class="stat-number">
                    <?php echo $total_lost; ?>
                </div>

            </div>


            <div class="stat-card green">

                <div class="stat-title">
                    Barang Dijumpai
                </div>

                <div class="stat-number">
                    <?php echo $total_found; ?>
                </div>

            </div>


            <div class="stat-card orange">

                <div class="stat-title">
                    Tuntutan Pending
                </div>

                <div class="stat-number">
                    <?php echo $total_pending_claims; ?>
                </div>

            </div>


        </div>


        <!-- =================================================
             QUICK ACTION
        ================================================= -->

        <div class="section">

            <div class="section-header">

                <h2>
                    Pengurusan Sistem
                </h2>

            </div>


            <div class="quick-actions">

                <a href="reports.php" class="quick-card">

                    <h3>
                        Urus Laporan
                    </h3>

                    <p>
                        Semak dan kemas kini status
                        laporan barang pelajar.
                    </p>

                </a>


                <a href="claims.php" class="quick-card">

                    <h3>
                        Semak Tuntutan
                    </h3>

                    <p>
                        Semak permohonan tuntutan
                        barang daripada pelajar.
                    </p>

                </a>


                <a href="users.php" class="quick-card">

                    <h3>
                        Urus Pengguna
                    </h3>

                    <p>
                        Lihat dan urus akaun
                        pengguna sistem.
                    </p>

                </a>

            </div>

        </div>


        <!-- =================================================
             LAPORAN TERKINI
        ================================================= -->

        <div class="section">

            <div class="section-header">

                <h2>
                    Laporan Terkini
                </h2>

                <a href="reports.php" class="view-all">
                    Lihat Semua
                </a>

            </div>


            <div class="table-wrapper">

                <?php

                if ($recent_items_result->num_rows > 0) {

                ?>

                    <table>

                        <thead>

                            <tr>

                                <th>
                                    Barang
                                </th>

                                <th>
                                    Jenis
                                </th>

                                <th>
                                    Kategori
                                </th>

                                <th>
                                    Pelapor
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Tarikh
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php

                        while ($item = $recent_items_result->fetch_assoc()) {

                            echo "<tr>";

                            echo "<td class='item-name'>"
                                . htmlspecialchars($item['item_name'])
                                . "</td>";


                            if ($item['item_type'] == "Lost") {

                                echo "<td>
                                    <span class='type-badge type-lost'>
                                        Hilang
                                    </span>
                                </td>";

                            } else {

                                echo "<td>
                                    <span class='type-badge type-found'>
                                        Dijumpai
                                    </span>
                                </td>";

                            }


                            echo "<td>"
                                . htmlspecialchars($item['category'])
                                . "</td>";


                            echo "<td>"
                                . htmlspecialchars($item['name'])
                                . "</td>";


                            if ($item['status'] == "Pending") {

                                echo "<td>
                                    <span class='status-badge status-pending'>
                                        Pending
                                    </span>
                                </td>";

                            } elseif ($item['status'] == "Found") {

                                echo "<td>
                                    <span class='status-badge status-found'>
                                        Dijumpai
                                    </span>
                                </td>";

                            } elseif ($item['status'] == "Claimed") {

                                echo "<td>
                                    <span class='status-badge status-claimed'>
                                        Dituntut
                                    </span>
                                </td>";

                            } else {

                                echo "<td>
                                    <span class='status-badge status-closed'>
                                        Ditutup
                                    </span>
                                </td>";

                            }


                            echo "<td>"
                                . htmlspecialchars($item['item_date'])
                                . "</td>";

                            echo "</tr>";

                        }

                        ?>

                        </tbody>

                    </table>

                <?php

                } else {

                    echo "
                    <div class='empty'>
                        Belum ada laporan.
                    </div>
                    ";

                }

                ?>

            </div>

        </div>


        <!-- =================================================
             TUNTUTAN TERKINI
        ================================================= -->

        <div class="section">

            <div class="section-header">

                <h2>
                    Tuntutan Terkini
                </h2>

                <a href="claims.php" class="view-all">
                    Lihat Semua
                </a>

            </div>


            <div class="table-wrapper">

                <?php

                if ($recent_claims_result->num_rows > 0) {

                ?>

                    <table>

                        <thead>

                            <tr>

                                <th>
                                    Barang
                                </th>

                                <th>
                                    Pemohon
                                </th>

                                <th>
                                    Sebab Tuntutan
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Tarikh
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php

                        while ($claim = $recent_claims_result->fetch_assoc()) {

                            echo "<tr>";

                            echo "<td class='item-name'>"
                                . htmlspecialchars($claim['item_name'])
                                . "</td>";


                            echo "<td>"
                                . htmlspecialchars($claim['name'])
                                . "</td>";


                            $reason = $claim['reason'];

                            if (strlen($reason) > 60) {
                                $reason = substr($reason, 0, 60) . "...";
                            }

                            echo "<td>"
                                . htmlspecialchars($reason)
                                . "</td>";


                            if ($claim['status'] == "Pending") {

                                echo "<td>
                                    <span class='status-badge status-pending'>
                                        Pending
                                    </span>
                                </td>";

                            } elseif ($claim['status'] == "Approved") {

                                echo "<td>
                                    <span class='status-badge status-approved'>
                                        Diluluskan
                                    </span>
                                </td>";

                            } else {

                                echo "<td>
                                    <span class='status-badge status-rejected'>
                                        Ditolak
                                    </span>
                                </td>";

                            }


                            echo "<td>"
                                . htmlspecialchars($claim['created_at'])
                                . "</td>";


                            echo "</tr>";

                        }

                        ?>

                        </tbody>

                    </table>

                <?php

                } else {

                    echo "
                    <div class='empty'>
                        Belum ada tuntutan.
                    </div>
                    ";

                }

                ?>

            </div>

        </div>


    </div>


</body>

</html>