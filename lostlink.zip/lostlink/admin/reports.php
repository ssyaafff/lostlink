<?php

session_start();
require_once "../config.php";


// =====================================================
// SEMAK LOGIN ADMIN
// =====================================================

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}


// =====================================================
// UPDATE STATUS
// =====================================================

$success = "";
$error = "";

if (isset($_POST['update_status'])) {

    $item_id = intval($_POST['item_id']);
    $status = $_POST['status'];

    $allowed_status = array(
        "Pending",
        "Found",
        "Claimed",
        "Closed"
    );

    if (!in_array($status, $allowed_status)) {

        $error = "Status tidak sah.";

    } else {

        $stmt = $mysqli->prepare("
            UPDATE items
            SET status = ?
            WHERE item_id = ?
        ");

        $stmt->bind_param(
            "si",
            $status,
            $item_id
        );

        if ($stmt->execute()) {

            $success = "Status laporan berjaya dikemas kini.";

        } else {

            $error = "Status gagal dikemas kini.";

        }

        $stmt->close();
    }
}


// =====================================================
// FILTER
// =====================================================

$search = "";
$type_filter = "";
$status_filter = "";

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

if (isset($_GET['type'])) {
    $type_filter = $_GET['type'];
}

if (isset($_GET['status'])) {
    $status_filter = $_GET['status'];
}


// =====================================================
// QUERY LAPORAN
// =====================================================

$sql = "
    SELECT
        items.*,
        users.name,
        users.matric_no
    FROM items
    INNER JOIN users
        ON items.user_id = users.user_id
    WHERE 1=1
";


$params = array();
$types = "";


// SEARCH

if ($search != "") {

    $sql .= "
        AND (
            items.item_name LIKE ?
            OR items.category LIKE ?
            OR items.location LIKE ?
            OR users.name LIKE ?
        )
    ";

    $search_value = "%" . $search . "%";

    $params[] = $search_value;
    $params[] = $search_value;
    $params[] = $search_value;
    $params[] = $search_value;

    $types .= "ssss";
}


// TYPE FILTER

if ($type_filter == "Lost" || $type_filter == "Found") {

    $sql .= "
        AND items.item_type = ?
    ";

    $params[] = $type_filter;
    $types .= "s";
}


// STATUS FILTER

if (
    $status_filter == "Pending" ||
    $status_filter == "Found" ||
    $status_filter == "Claimed" ||
    $status_filter == "Closed"
) {

    $sql .= "
        AND items.status = ?
    ";

    $params[] = $status_filter;
    $types .= "s";
}


$sql .= "
    ORDER BY items.created_at DESC
";


$stmt = $mysqli->prepare($sql);


// Bind parameter kalau ada

if (count($params) > 0) {

    $bind_values = array();

    $bind_values[] = $types;

    foreach ($params as $key => $value) {
        $bind_values[] = &$params[$key];
    }

    call_user_func_array(
        array($stmt, "bind_param"),
        $bind_values
    );
}


$stmt->execute();

$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="ms">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Urus Laporan - LostLink</title>


    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }


        body {
            font-family: Arial, sans-serif;
            background: #f5f8fc;
            color: #1f2937;
        }


        /* =====================================================
           NAVBAR
        ===================================================== */

        .navbar {
            width: 100%;
            min-height: 75px;
            background: white;
            display: flex;
            align-items: center;
            padding: 0 6%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }


        .logo {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }


        .logo img {
            width: 150px;
            height: auto;
            display: block;
        }


        .nav-links {
            margin-left: auto;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
            white-space: nowrap;
        }


        .nav-links a {
            text-decoration: none;
            color: #374151;
            font-size: 14px;
            font-weight: 600;
        }


        .nav-links a:hover {
            color: #2563eb;
        }


        .logout {
            background: #ef4444;
            color: white !important;
            padding: 9px 15px;
            border-radius: 7px;
        }


        .logout:hover {
            background: #dc2626 !important;
        }


        /* =====================================================
           CONTAINER
        ===================================================== */

        .container {
            width: 90%;
            max-width: 1250px;
            margin: 40px auto;
        }


        .page-header {
            margin-bottom: 25px;
        }


        .page-header h1 {
            font-size: 28px;
            color: #111827;
            margin-bottom: 7px;
        }


        .page-header p {
            color: #64748b;
        }


        /* =====================================================
           MESSAGE
        ===================================================== */

        .success {
            background: #dcfce7;
            color: #166534;
            padding: 14px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }


        .error {
            background: #fee2e2;
            color: #b91c1c;
            padding: 14px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }


        /* =====================================================
           FILTER
        ===================================================== */

        .filter-card {
            background: white;
            padding: 22px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }


        .filter-form {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr auto;
            gap: 12px;
        }


        .filter-form input,
        .filter-form select {
            width: 100%;
            padding: 11px 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            background: white;
        }


        .filter-form input:focus,
        .filter-form select:focus {
            outline: none;
            border-color: #2563eb;
        }


        .btn {
            display: inline-block;
            padding: 11px 18px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }


        .btn-primary {
            background: #2563eb;
            color: white;
        }


        .btn-primary:hover {
            background: #1d4ed8;
        }


        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }


        .btn-secondary:hover {
            background: #d1d5db;
        }


        /* =====================================================
           TABLE
        ===================================================== */

        .table-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }


        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }


        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1050px;
        }


        th {
            text-align: left;
            background: #f8fafc;
            color: #64748b;
            font-size: 12px;
            padding: 13px;
            border-bottom: 1px solid #e5e7eb;
        }


        td {
            padding: 14px 13px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 13px;
            vertical-align: middle;
        }


        tr:last-child td {
            border-bottom: none;
        }


        .item-name {
            font-weight: bold;
            color: #1f2937;
        }


        .small-text {
            color: #64748b;
            font-size: 12px;
            margin-top: 4px;
        }


        /* =====================================================
           BADGES
        ===================================================== */

        .badge {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 15px;
            font-size: 11px;
            font-weight: bold;
            white-space: nowrap;
        }


        .type-lost {
            background: #fee2e2;
            color: #b91c1c;
        }


        .type-found {
            background: #dcfce7;
            color: #15803d;
        }


        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }


        .status-found {
            background: #dcfce7;
            color: #166534;
        }


        .status-claimed {
            background: #dbeafe;
            color: #1d4ed8;
        }


        .status-closed {
            background: #e5e7eb;
            color: #4b5563;
        }


        /* =====================================================
           STATUS FORM
        ===================================================== */

        .status-form {
            display: flex;
            gap: 7px;
            align-items: center;
        }


        .status-form select {
            padding: 7px 8px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 12px;
            background: white;
        }


        .update-btn {
            padding: 7px 10px;
            background: #2563eb;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 11px;
            font-weight: bold;
        }


        .update-btn:hover {
            background: #1d4ed8;
        }


        .detail-btn {
            display: inline-block;
            padding: 7px 10px;
            background: #eff6ff;
            color: #2563eb;
            border-radius: 6px;
            text-decoration: none;
            font-size: 11px;
            font-weight: bold;
        }


        .detail-btn:hover {
            background: #dbeafe;
        }


        /* =====================================================
           EMPTY
        ===================================================== */

        .empty {
            text-align: center;
            padding: 50px 20px;
            color: #94a3b8;
        }


        .empty h3 {
            color: #64748b;
            margin-bottom: 8px;
        }


        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 900px) {

            .filter-form {
                grid-template-columns: 1fr 1fr;
            }

        }


        @media (max-width: 750px) {

            .navbar {
                padding: 15px 5%;
                flex-direction: column;
                gap: 15px;
            }


            .nav-links {
                margin-left: 0;
                justify-content: center;
                flex-wrap: wrap;
                gap: 12px;
            }


            .filter-form {
                grid-template-columns: 1fr;
            }

        }


        @media (max-width: 500px) {

            .container {
                width: 94%;
                margin: 25px auto;
            }


            .page-header h1 {
                font-size: 23px;
            }


            .table-card {
                padding: 12px;
            }

        }

    </style>

</head>


<body>


    <!-- =====================================================
         NAVBAR
    ===================================================== -->

    <nav class="navbar">

        <a href="dashboard.php" class="logo">

            <img
                src="../assets/lostlink-logo.png"
                alt="LostLink Logo"
            >

        </a>


        <div class="nav-links">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="reports.php">
                Laporan
            </a>

            <a href="claims.php">
                Tuntutan
            </a>

            <a href="users.php">
                Pengguna
            </a>

            <a href="../logout.php" class="logout">
                Log Keluar
            </a>

        </div>

    </nav>


    <!-- =====================================================
         MAIN
    ===================================================== -->

    <div class="container">


        <div class="page-header">

            <h1>
                Urus Laporan
            </h1>

            <p>
                Semak semua laporan barang hilang dan dijumpai
                yang dihantar oleh pelajar.
            </p>

        </div>


        <!-- MESSAGE -->

        <?php

        if ($success != "") {

            echo "
            <div class='success'>
                " . htmlspecialchars($success) . "
            </div>
            ";

        }


        if ($error != "") {

            echo "
            <div class='error'>
                " . htmlspecialchars($error) . "
            </div>
            ";

        }

        ?>


        <!-- =================================================
             FILTER
        ================================================= -->

        <div class="filter-card">

            <form
                method="GET"
                class="filter-form"
            >


                <input
                    type="text"
                    name="search"
                    placeholder="Cari barang, kategori, lokasi atau nama pelapor..."
                    value="<?php echo htmlspecialchars($search); ?>"
                >


                <select name="type">

                    <option value="">
                        Semua Jenis
                    </option>

                    <option
                        value="Lost"
                        <?php
                        if ($type_filter == "Lost") {
                            echo "selected";
                        }
                        ?>
                    >
                        Barang Hilang
                    </option>

                    <option
                        value="Found"
                        <?php
                        if ($type_filter == "Found") {
                            echo "selected";
                        }
                        ?>
                    >
                        Barang Dijumpai
                    </option>

                </select>


                <select name="status">

                    <option value="">
                        Semua Status
                    </option>

                    <option
                        value="Pending"
                        <?php
                        if ($status_filter == "Pending") {
                            echo "selected";
                        }
                        ?>
                    >
                        Pending
                    </option>

                    <option
                        value="Found"
                        <?php
                        if ($status_filter == "Found") {
                            echo "selected";
                        }
                        ?>
                    >
                        Dijumpai
                    </option>

                    <option
                        value="Claimed"
                        <?php
                        if ($status_filter == "Claimed") {
                            echo "selected";
                        }
                        ?>
                    >
                        Dituntut
                    </option>

                    <option
                        value="Closed"
                        <?php
                        if ($status_filter == "Closed") {
                            echo "selected";
                        }
                        ?>
                    >
                        Ditutup
                    </option>

                </select>


                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    Cari
                </button>


            </form>

        </div>


        <!-- =================================================
             REPORT TABLE
        ================================================= -->

        <div class="table-card">

            <div class="table-wrapper">

                <?php

                if ($result->num_rows > 0) {

                ?>

                    <table>

                        <thead>

                            <tr>

                                <th>
                                    Barang
                                </th>

                                <th>
                                    Jenis
                                </th>

                                <th>
                                    Kategori
                                </th>

                                <th>
                                    Lokasi
                                </th>

                                <th>
                                    Pelapor
                                </th>

                                <th>
                                    Tarikh
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Tindakan
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                        <?php

                        while ($item = $result->fetch_assoc()) {

                        ?>

                            <tr>


                                <!-- BARANG -->

                                <td>

                                    <div class="item-name">

                                        <?php
                                        echo htmlspecialchars(
                                            $item['item_name']
                                        );
                                        ?>

                                    </div>


                                    <div class="small-text">

                                        ID:
                                        <?php
                                        echo $item['item_id'];
                                        ?>

                                    </div>

                                </td>


                                <!-- JENIS -->

                                <td>

                                    <?php

                                    if ($item['item_type'] == "Lost") {

                                        echo "
                                        <span class='badge type-lost'>
                                            Hilang
                                        </span>
                                        ";

                                    } else {

                                        echo "
                                        <span class='badge type-found'>
                                            Dijumpai
                                        </span>
                                        ";

                                    }

                                    ?>

                                </td>


                                <!-- KATEGORI -->

                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        $item['category']
                                    );
                                    ?>

                                </td>


                                <!-- LOKASI -->

                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        $item['location']
                                    );
                                    ?>

                                </td>


                                <!-- PELAPOR -->

                                <td>

                                    <div>
                                        <?php
                                        echo htmlspecialchars(
                                            $item['name']
                                        );
                                        ?>
                                    </div>

                                    <div class="small-text">
                                        <?php
                                        echo htmlspecialchars(
                                            $item['matric_no']
                                        );
                                        ?>
                                    </div>

                                </td>


                                <!-- TARIKH -->

                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        $item['item_date']
                                    );
                                    ?>

                                </td>


                                <!-- STATUS -->

                                <td>

                                    <?php

                                    if ($item['status'] == "Pending") {

                                        echo "
                                        <span class='badge status-pending'>
                                            Pending
                                        </span>
                                        ";

                                    } elseif ($item['status'] == "Found") {

                                        echo "
                                        <span class='badge status-found'>
                                            Dijumpai
                                        </span>
                                        ";

                                    } elseif ($item['status'] == "Claimed") {

                                        echo "
                                        <span class='badge status-claimed'>
                                            Dituntut
                                        </span>
                                        ";

                                    } else {

                                        echo "
                                        <span class='badge status-closed'>
                                            Ditutup
                                        </span>
                                        ";

                                    }

                                    ?>

                                </td>


                                <!-- TINDAKAN -->

                                <td>


                                    <form
                                        method="POST"
                                        class="status-form"
                                    >

                                        <input
                                            type="hidden"
                                            name="item_id"
                                            value="<?php echo $item['item_id']; ?>"
                                        >


                                        <select name="status">

                                            <option
                                                value="Pending"
                                                <?php

                                                if (
                                                    $item['status']
                                                    == "Pending"
                                                ) {
                                                    echo "selected";
                                                }

                                                ?>
                                            >
                                                Pending
                                            </option>


                                            <option
                                                value="Found"
                                                <?php

                                                if (
                                                    $item['status']
                                                    == "Found"
                                                ) {
                                                    echo "selected";
                                                }

                                                ?>
                                            >
                                                Dijumpai
                                            </option>


                                            <option
                                                value="Claimed"
                                                <?php

                                                if (
                                                    $item['status']
                                                    == "Claimed"
                                                ) {
                                                    echo "selected";
                                                }

                                                ?>
                                            >
                                                Dituntut
                                            </option>


                                            <option
                                                value="Closed"
                                                <?php

                                                if (
                                                    $item['status']
                                                    == "Closed"
                                                ) {
                                                    echo "selected";
                                                }

                                                ?>
                                            >
                                                Ditutup
                                            </option>

                                        </select>


                                        <button
                                            type="submit"
                                            name="update_status"
                                            class="update-btn"
                                        >
                                            Simpan
                                        </button>

                                    </form>


                                    <br>


                                    <a
                                        href="../item_details.php?id=<?php echo $item['item_id']; ?>"
                                        class="detail-btn"
                                    >
                                        Lihat Detail
                                    </a>


                                </td>


                            </tr>

                        <?php

                        }

                        ?>

                        </tbody>

                    </table>

                <?php

                } else {

                ?>

                    <div class="empty">

                        <h3>
                            Tiada Laporan
                        </h3>

                        <p>
                            Tiada laporan yang sepadan dengan carian anda.
                        </p>

                    </div>

                <?php

                }

                ?>

            </div>

        </div>


    </div>


</body>

</html>

<?php

$stmt->close();

?>