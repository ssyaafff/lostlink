<?php

session_start();
require_once "../config.php";

// =====================================================
// SEMAK ADMIN
// =====================================================

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['role'] != 'admin') {
    header("Location: ../dashboard.php");
    exit();
}


// =====================================================
// PADAM PENGGUNA
// =====================================================

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $user_id = intval($_POST['user_id']);
    $action = $_POST['action'];

    if ($action == "delete") {

        // Semak pengguna
        $stmt = $mysqli->prepare("
            SELECT role
            FROM users
            WHERE user_id = ?
        ");

        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        $result_user = $stmt->get_result();

        if ($result_user->num_rows > 0) {

            $user = $result_user->fetch_assoc();

            // Jangan benarkan admin dipadam
            if ($user['role'] != 'admin') {

                $stmt_delete = $mysqli->prepare("
                    DELETE FROM users
                    WHERE user_id = ?
                    AND role = 'student'
                ");

                $stmt_delete->bind_param("i", $user_id);
                $stmt_delete->execute();

                header("Location: users.php?success=deleted");
                exit();

            } else {

                header("Location: users.php?error=admin");
                exit();
            }

        } else {

            header("Location: users.php?error=notfound");
            exit();
        }
    }
}


// =====================================================
// SEARCH & FILTER
// =====================================================

$search = "";

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

$role_filter = "";

if (isset($_GET['role'])) {
    $role_filter = $_GET['role'];
}


// =====================================================
// QUERY USERS
// =====================================================

$sql = "
    SELECT
        user_id,
        name,
        matric_no,
        email,
        role,
        created_at
    FROM users
    WHERE 1=1
";

$params = array();
$types = "";


// Search
if ($search != "") {

    $sql .= "
        AND (
            name LIKE ?
            OR matric_no LIKE ?
            OR email LIKE ?
        )
    ";

    $search_value = "%" . $search . "%";

    $params[] = $search_value;
    $params[] = $search_value;
    $params[] = $search_value;

    $types .= "sss";
}


// Filter role
if ($role_filter != "") {

    $sql .= " AND role = ? ";

    $params[] = $role_filter;
    $types .= "s";
}


$sql .= " ORDER BY created_at DESC";


// =====================================================
// PREPARED STATEMENT
// =====================================================

$stmt = $mysqli->prepare($sql);

if (count($params) > 0) {

    $bind_names = array();
    $bind_names[] = $types;

    for ($i = 0; $i < count($params); $i++) {
        $bind_names[] = &$params[$i];
    }

    call_user_func_array(
        array($stmt, "bind_param"),
        $bind_names
    );
}

$stmt->execute();

$result = $stmt->get_result();


// =====================================================
// JUMLAH PENGGUNA
// =====================================================

$total_users = 0;
$total_students = 0;
$total_admins = 0;

$count_result = $mysqli->query("
    SELECT
        COUNT(*) AS total_users,
        SUM(role = 'student') AS total_students,
        SUM(role = 'admin') AS total_admins
    FROM users
");

if ($count_result) {

    $count_data = $count_result->fetch_assoc();

    $total_users = $count_data['total_users'];
    $total_students = $count_data['total_students'];
    $total_admins = $count_data['total_admins'];
}

?>

<!DOCTYPE html>
<html lang="ms">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pengurusan Pengguna - LostLink</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f7fb;
            color: #1f2937;
        }


        /* =========================
           NAVBAR
        ========================= */

        .navbar {
            width: 100%;
            min-height: 75px;
            background: white;
            display: flex;
            align-items: center;
            padding: 0 6%;
            border-bottom: 1px solid #e5e7eb;
        }

        .logo {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }

        .logo img {
            width: 145px;
            height: auto;
            display: block;
        }

        .nav-links {
            margin-left: auto;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
            white-space: nowrap;
        }

        .nav-links a {
            text-decoration: none;
            color: #374151;
            font-size: 14px;
            font-weight: 600;
        }

        .nav-links a:hover {
            color: #2563eb;
        }

        .logout {
            color: #dc2626 !important;
        }


        /* =========================
           CONTAINER
        ========================= */

        .container {
            width: 90%;
            max-width: 1400px;
            margin: 35px auto;
        }

        .page-title {
            margin-bottom: 25px;
        }

        .page-title h1 {
            font-size: 28px;
            color: #111827;
            margin-bottom: 7px;
        }

        .page-title p {
            color: #6b7280;
            font-size: 14px;
        }


        /* =========================
           ALERT
        ========================= */

        .alert {
            padding: 14px 18px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 600;
        }

        .success {
            background: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }


        /* =========================
           STAT CARDS
        ========================= */

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 20px;
        }

        .stat-label {
            color: #6b7280;
            font-size: 13px;
            margin-bottom: 8px;
        }

        .stat-number {
            font-size: 28px;
            font-weight: 700;
            color: #111827;
        }


        /* =========================
           FILTER
        ========================= */

        .filter-box {
            background: white;
            padding: 20px;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            margin-bottom: 25px;
        }

        .filter-form {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .filter-form input,
        .filter-form select {
            height: 42px;
            padding: 0 12px;
            border: 1px solid #d1d5db;
            border-radius: 7px;
            font-size: 14px;
            outline: none;
        }

        .filter-form input {
            flex: 1;
            min-width: 250px;
        }

        .filter-form input:focus,
        .filter-form select:focus {
            border-color: #2563eb;
        }

        .btn-search {
            background: #2563eb;
            color: white;
            border: none;
            padding: 0 22px;
            border-radius: 7px;
            cursor: pointer;
            font-weight: 600;
        }

        .btn-search:hover {
            background: #1d4ed8;
        }


        /* =========================
           TABLE
        ========================= */

        .table-box {
            background: white;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }

        th {
            background: #f8fafc;
            padding: 15px;
            text-align: left;
            font-size: 13px;
            color: #475569;
            border-bottom: 1px solid #e5e7eb;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
            font-size: 13px;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover {
            background: #fafafa;
        }


        /* =========================
           USER
        ========================= */

        .user-name {
            font-weight: 700;
            color: #111827;
            margin-bottom: 4px;
        }

        .user-email {
            color: #6b7280;
            font-size: 12px;
        }


        /* =========================
           BADGES
        ========================= */

        .badge {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
        }

        .student {
            background: #dbeafe;
            color: #1e40af;
        }

        .admin {
            background: #ede9fe;
            color: #6d28d9;
        }


        /* =========================
           BUTTON
        ========================= */

        .btn-delete {
            background: #fee2e2;
            color: #dc2626;
            border: none;
            border-radius: 6px;
            padding: 8px 12px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }

        .btn-delete:hover {
            background: #fecaca;
        }

        .protected {
            color: #9ca3af;
            font-size: 12px;
        }


        /* =========================
           EMPTY
        ========================= */

        .empty {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }

        .empty h3 {
            color: #374151;
            margin-bottom: 8px;
        }


        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 800px) {

            .navbar {
                padding: 15px 5%;
                flex-direction: column;
                gap: 12px;
            }

            .nav-links {
                margin-left: 0;
                justify-content: center;
                flex-wrap: wrap;
            }

            .container {
                width: 94%;
                margin-top: 25px;
            }

            .stats {
                grid-template-columns: 1fr;
            }

            .page-title h1 {
                font-size: 24px;
            }

            .filter-form {
                flex-direction: column;
            }

            .filter-form input {
                width: 100%;
            }

            .filter-form select,
            .btn-search {
                width: 100%;
                height: 42px;
            }
        }

    </style>

</head>


<body>


<!-- =====================================================
     NAVBAR
===================================================== -->

<div class="navbar">

    <div class="logo">

        <a href="dashboard.php">

            <img
                src="../assets/lostlink-logo.png"
                alt="LostLink Logo"
            >

        </a>

    </div>


    <div class="nav-links">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="reports.php">
            Laporan
        </a>

        <a href="claims.php">
            Tuntutan
        </a>

        <a href="users.php">
            Pengguna
        </a>

        <a href="../logout.php" class="logout">
            Log Keluar
        </a>

    </div>

</div>


<!-- =====================================================
     CONTENT
===================================================== -->

<div class="container">


    <div class="page-title">

        <h1>
            Pengurusan Pengguna
        </h1>

        <p>
            Lihat dan urus akaun pelajar yang menggunakan sistem LostLink.
        </p>

    </div>


    <!-- =================================================
         ALERT
    ================================================== -->

    <?php if (isset($_GET['success'])) { ?>

        <?php if ($_GET['success'] == "deleted") { ?>

            <div class="alert success">
                Pengguna telah berjaya dipadam.
            </div>

        <?php } ?>

    <?php } ?>


    <?php if (isset($_GET['error'])) { ?>

        <?php if ($_GET['error'] == "admin") { ?>

            <div class="alert error">
                Akaun admin tidak boleh dipadam.
            </div>

        <?php } ?>


        <?php if ($_GET['error'] == "notfound") { ?>

            <div class="alert error">
                Pengguna tidak dijumpai.
            </div>

        <?php } ?>

    <?php } ?>


    <!-- =================================================
         STATISTICS
    ================================================== -->

    <div class="stats">


        <div class="stat-card">

            <div class="stat-label">
                Jumlah Pengguna
            </div>

            <div class="stat-number">
                <?php echo $total_users; ?>
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-label">
                Pelajar
            </div>

            <div class="stat-number">
                <?php echo $total_students; ?>
            </div>

        </div>


        <div class="stat-card">

            <div class="stat-label">
                Admin
            </div>

            <div class="stat-number">
                <?php echo $total_admins; ?>
            </div>

        </div>


    </div>


    <!-- =================================================
         SEARCH & FILTER
    ================================================== -->

    <div class="filter-box">

        <form method="GET" class="filter-form">


            <input
                type="text"
                name="search"
                placeholder="Cari nama, no. matrik atau email..."
                value="<?php echo htmlspecialchars($search); ?>"
            >


            <select name="role">

                <option value="">
                    Semua Role
                </option>


                <option
                    value="student"
                    <?php

                    if ($role_filter == "student") {
                        echo "selected";
                    }

                    ?>
                >
                    Pelajar
                </option>


                <option
                    value="admin"
                    <?php

                    if ($role_filter == "admin") {
                        echo "selected";
                    }

                    ?>
                >
                    Admin
                </option>

            </select>


            <button
                type="submit"
                class="btn-search"
            >
                Cari
            </button>


        </form>

    </div>


    <!-- =================================================
         USER TABLE
    ================================================== -->

    <div class="table-box">


        <?php if ($result->num_rows > 0) { ?>


            <table>


                <thead>

                    <tr>

                        <th>
                            Pengguna
                        </th>

                        <th>
                            No. Matrik
                        </th>

                        <th>
                            Role
                        </th>

                        <th>
                            Tarikh Daftar
                        </th>

                        <th>
                            Tindakan
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php while ($row = $result->fetch_assoc()) { ?>


                    <tr>


                        <!-- USER -->

                        <td>

                            <div class="user-name">

                                <?php
                                echo htmlspecialchars($row['name']);
                                ?>

                            </div>


                            <div class="user-email">

                                <?php
                                echo htmlspecialchars($row['email']);
                                ?>

                            </div>

                        </td>


                        <!-- MATRIC -->

                        <td>

                            <?php
                            echo htmlspecialchars($row['matric_no']);
                            ?>

                        </td>


                        <!-- ROLE -->

                        <td>


                            <?php if ($row['role'] == "admin") { ?>

                                <span class="badge admin">
                                    Admin
                                </span>

                            <?php } else { ?>

                                <span class="badge student">
                                    Pelajar
                                </span>

                            <?php } ?>


                        </td>


                        <!-- DATE -->

                        <td>

                            <?php

                            echo date(
                                "d/m/Y H:i",
                                strtotime($row['created_at'])
                            );

                            ?>

                        </td>


                        <!-- ACTION -->

                        <td>


                            <?php if ($row['role'] == "student") { ?>


                                <form
                                    method="POST"
                                    onsubmit="return confirm('Adakah anda pasti mahu memadam pengguna ini? Semua laporan dan tuntutan pengguna ini juga boleh terjejas.');"
                                >


                                    <input
                                        type="hidden"
                                        name="user_id"
                                        value="<?php echo $row['user_id']; ?>"
                                    >


                                    <input
                                        type="hidden"
                                        name="action"
                                        value="delete"
                                    >


                                    <button
                                        type="submit"
                                        class="btn-delete"
                                    >
                                        Padam
                                    </button>


                                </form>


                            <?php } else { ?>


                                <span class="protected">
                                    Akaun dilindungi
                                </span>


                            <?php } ?>


                        </td>


                    </tr>


                <?php } ?>


                </tbody>


            </table>


        <?php } else { ?>


            <div class="empty">

                <h3>
                    Tiada Pengguna
                </h3>

                <p>
                    Tiada pengguna yang sepadan dengan carian anda.
                </p>

            </div>


        <?php } ?>


    </div>


</div>


</body>

</html>