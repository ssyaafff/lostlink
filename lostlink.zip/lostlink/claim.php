<?php

session_start();
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if (!isset($_GET['id'])) {
    header("Location: search.php");
    exit();
}

$item_id = intval($_GET['id']);


// =====================================================
// DAPATKAN MAKLUMAT BARANG
// =====================================================

$sql = "
    SELECT items.*, users.name
    FROM items
    INNER JOIN users ON items.user_id = users.user_id
    WHERE items.item_id = '$item_id'
";

$result = $mysqli->query($sql);

if ($result->num_rows == 0) {
    header("Location: search.php");
    exit();
}

$item = $result->fetch_assoc();


// =====================================================
// SEMAK BARANG
// =====================================================

if ($item['item_type'] != "Found") {
    header("Location: item_details.php?id=" . $item_id);
    exit();
}

if ($item['user_id'] == $user_id) {
    header("Location: item_details.php?id=" . $item_id);
    exit();
}

if ($item['status'] == "Claimed" || $item['status'] == "Closed") {
    header("Location: item_details.php?id=" . $item_id);
    exit();
}


// =====================================================
// SEMAK CLAIM SEDIA ADA
// =====================================================

$check_claim = "
    SELECT *
    FROM claims
    WHERE item_id = '$item_id'
    AND user_id = '$user_id'
    AND status IN ('Pending', 'Approved')
";

$claim_result = $mysqli->query($check_claim);

if ($claim_result->num_rows > 0) {
    header("Location: item_details.php?id=" . $item_id);
    exit();
}


// =====================================================
// PROSES BORANG
// =====================================================

$error = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $reason = trim($_POST['reason']);

    if ($reason == "") {

        $error = "Sila masukkan sebab atau bukti bahawa barang ini milik anda.";

    } else {

        $proof_image = "";

        // =====================================================
        // UPLOAD BUKTI GAMBAR
        // =====================================================

        if (isset($_FILES['proof_image'])) {

            if ($_FILES['proof_image']['error'] == 0) {

                $file_name = $_FILES['proof_image']['name'];
                $file_tmp = $_FILES['proof_image']['tmp_name'];
                $file_size = $_FILES['proof_image']['size'];

                $file_ext = strtolower(
                    pathinfo($file_name, PATHINFO_EXTENSION)
                );

                $allowed_ext = array(
                    "jpg",
                    "jpeg",
                    "png"
                );

                if (!in_array($file_ext, $allowed_ext)) {

                    $error = "Format gambar mestilah JPG, JPEG atau PNG.";

                } elseif ($file_size > 5 * 1024 * 1024) {

                    $error = "Saiz gambar tidak boleh melebihi 5MB.";

                } else {

                    $new_file_name =
                        time() . "_" . uniqid() . "." . $file_ext;

                    $upload_folder = "uploads/claims/";

                    if (!is_dir($upload_folder)) {
                        mkdir($upload_folder, 0777, true);
                    }

                    $upload_path =
                        $upload_folder . $new_file_name;

                    if (move_uploaded_file($file_tmp, $upload_path)) {

                        $proof_image = $new_file_name;

                    } else {

                        $error = "Gagal memuat naik gambar.";

                    }

                }

            }

        }


        // =====================================================
        // SIMPAN CLAIM
        // =====================================================

        if ($error == "") {

            $reason = $mysqli->real_escape_string($reason);
            $proof_image = $mysqli->real_escape_string($proof_image);

            $insert_claim = "
                INSERT INTO claims
                (
                    item_id,
                    user_id,
                    reason,
                    proof_image,
                    status
                )
                VALUES
                (
                    '$item_id',
                    '$user_id',
                    '$reason',
                    '$proof_image',
                    'Pending'
                )
            ";

            if ($mysqli->query($insert_claim)) {

                header(
                    "Location: item_details.php?id="
                    . $item_id
                    . "&claim=success"
                );

                exit();

            } else {

                $error = "Permohonan tuntutan gagal dihantar.";
            }

        }

    }

}

?>

<!DOCTYPE html>
<html lang="ms">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Tuntut Barang - LostLink</title>


    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }


        body {
            font-family: Arial, sans-serif;
            background: #f5f8fc;
            color: #1f2937;
        }


        /* ================= NAVBAR ================= */

        .navbar {
            width: 100%;
            min-height: 75px;
            background: white;
            display: flex;
            align-items: center;
            padding: 0 6%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }


        .logo {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }


        .logo img {
            width: 150px;
            height: auto;
            display: block;
        }


        .nav-links {
            margin-left: auto;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
            white-space: nowrap;
        }


        .nav-links a {
            text-decoration: none;
            color: #374151;
            font-size: 14px;
            font-weight: 600;
        }


        .nav-links a:hover {
            color: #2563eb;
        }


        .logout {
            background: #ef4444;
            color: white !important;
            padding: 9px 15px;
            border-radius: 7px;
        }


        .logout:hover {
            background: #dc2626 !important;
        }


        /* ================= CONTAINER ================= */

        .container {
            width: 90%;
            max-width: 900px;
            margin: 40px auto;
        }


        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #2563eb;
            text-decoration: none;
            font-weight: 600;
        }


        .back-link:hover {
            text-decoration: underline;
        }


        /* ================= CARD ================= */

        .claim-card {
            background: white;
            border-radius: 18px;
            padding: 35px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.07);
        }


        .page-title {
            font-size: 28px;
            color: #111827;
            margin-bottom: 8px;
        }


        .page-description {
            color: #64748b;
            margin-bottom: 30px;
            line-height: 1.6;
        }


        /* ================= ITEM INFO ================= */

        .item-preview {
            background: #eff6ff;
            border: 1px solid #dbeafe;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
        }


        .item-preview h3 {
            color: #1e3a8a;
            margin-bottom: 15px;
        }


        .item-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }


        .item-info div {
            color: #475569;
            font-size: 14px;
        }


        .item-info strong {
            color: #1f2937;
        }


        /* ================= FORM ================= */

        .form-group {
            margin-bottom: 22px;
        }


        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #374151;
        }


        textarea {
            width: 100%;
            min-height: 150px;
            resize: vertical;
            padding: 13px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            outline: none;
        }


        textarea:focus {
            border-color: #2563eb;
        }


        input[type="file"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            background: white;
        }


        .help-text {
            margin-top: 7px;
            color: #64748b;
            font-size: 12px;
        }


        /* ================= ERROR ================= */

        .error {
            background: #fee2e2;
            color: #b91c1c;
            padding: 13px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }


        /* ================= BUTTON ================= */

        .button-area {
            display: flex;
            gap: 12px;
            margin-top: 25px;
        }


        .btn {
            display: inline-block;
            padding: 12px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
            border: none;
            cursor: pointer;
        }


        .btn-primary {
            background: #2563eb;
            color: white;
        }


        .btn-primary:hover {
            background: #1d4ed8;
        }


        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }


        .btn-secondary:hover {
            background: #d1d5db;
        }


        /* ================= RESPONSIVE ================= */

        @media (max-width: 750px) {

            .navbar {
                padding: 15px 5%;
                flex-direction: column;
                gap: 15px;
            }


            .nav-links {
                margin-left: 0;
                justify-content: center;
                flex-wrap: wrap;
                gap: 12px;
            }


            .item-info {
                grid-template-columns: 1fr;
            }

        }


        @media (max-width: 500px) {

            .container {
                width: 94%;
                margin: 25px auto;
            }


            .claim-card {
                padding: 22px;
            }


            .page-title {
                font-size: 23px;
            }


            .button-area {
                flex-direction: column;
            }


            .btn {
                text-align: center;
            }

        }

    </style>

</head>


<body>


    <!-- NAVBAR -->

    <nav class="navbar">

        <a href="dashboard.php" class="logo">

            <img
                src="assets/lostlink-logo.png"
                alt="LostLink Logo"
            >

        </a>


        <div class="nav-links">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="search.php">
                Cari Barang
            </a>

            <a href="my_reports.php">
                Laporan Saya
            </a>

            <a href="profile.php">
                Profil
            </a>

            <a href="logout.php" class="logout">
                Log Keluar
            </a>

        </div>

    </nav>


    <!-- MAIN -->

    <div class="container">

        <a
            href="item_details.php?id=<?php echo $item_id; ?>"
            class="back-link"
        >
            ← Kembali ke Detail Barang
        </a>


        <div class="claim-card">

            <h1 class="page-title">
                Tuntut Barang
            </h1>


            <p class="page-description">
                Sila berikan maklumat yang boleh membantu pihak admin
                mengesahkan bahawa barang ini adalah milik anda.
            </p>


            <?php

            if ($error != "") {

                echo "
                <div class='error'>
                    " . htmlspecialchars($error) . "
                </div>
                ";

            }

            ?>


            <!-- ITEM PREVIEW -->

            <div class="item-preview">

                <h3>
                    Maklumat Barang
                </h3>


                <div class="item-info">

                    <div>
                        <strong>Nama Barang:</strong>
                        <?php echo htmlspecialchars($item['item_name']); ?>
                    </div>


                    <div>
                        <strong>Kategori:</strong>
                        <?php echo htmlspecialchars($item['category']); ?>
                    </div>


                    <div>
                        <strong>Lokasi:</strong>
                        <?php echo htmlspecialchars($item['location']); ?>
                    </div>


                    <div>
                        <strong>Tarikh:</strong>
                        <?php echo htmlspecialchars($item['item_date']); ?>
                    </div>

                </div>

            </div>


            <!-- CLAIM FORM -->

            <form
                method="POST"
                enctype="multipart/form-data"
            >


                <div class="form-group">

                    <label for="reason">
                        Sebab / Bukti Tuntutan
                    </label>


                    <textarea
                        name="reason"
                        id="reason"
                        placeholder="Contoh: Barang ini mempunyai tanda khas / ciri tertentu yang boleh membuktikan ia milik saya."
                        required
                    ></textarea>


                    <div class="help-text">
                        Terangkan ciri-ciri barang yang boleh membantu admin
                        mengesahkan tuntutan anda.
                    </div>

                </div>


                <div class="form-group">

                    <label for="proof_image">
                        Gambar Bukti
                    </label>


                    <input
                        type="file"
                        name="proof_image"
                        id="proof_image"
                        accept=".jpg,.jpeg,.png"
                    >


                    <div class="help-text">
                        Pilihan. Format JPG, JPEG atau PNG. Maksimum 5MB.
                    </div>

                </div>


                <div class="button-area">

                    <a
                        href="item_details.php?id=<?php echo $item_id; ?>"
                        class="btn btn-secondary"
                    >
                        Batal
                    </a>


                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        Hantar Tuntutan
                    </button>

                </div>


            </form>

        </div>

    </div>


</body>

</html>