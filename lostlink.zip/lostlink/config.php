<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "lostlink";

$mysqli = new mysqli($host, $user, $password, $database);

if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

$mysqli->set_charset("utf8");

?>