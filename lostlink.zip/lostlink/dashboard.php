<?php

session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {

    header("Location: login.php");
    exit;

}

$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'];


/* =========================
   JUMLAH LAPORAN SAYA
   ========================= */

$sql_total = "SELECT COUNT(*) AS total 
              FROM items 
              WHERE user_id='$user_id'";

$result_total = $mysqli->query($sql_total);
$data_total = $result_total->fetch_assoc();

$total_reports = $data_total['total'];


/* =========================
   JUMLAH BARANG HILANG
   ========================= */

$sql_lost = "SELECT COUNT(*) AS total 
             FROM items 
             WHERE user_id='$user_id'
             AND item_type='Lost'";

$result_lost = $mysqli->query($sql_lost);
$data_lost = $result_lost->fetch_assoc();

$total_lost = $data_lost['total'];


/* =========================
   JUMLAH BARANG DIJUMPAI
   ========================= */

$sql_found = "SELECT COUNT(*) AS total 
              FROM items 
              WHERE user_id='$user_id'
              AND item_type='Found'";

$result_found = $mysqli->query($sql_found);
$data_found = $result_found->fetch_assoc();

$total_found = $data_found['total'];


/* =========================
   LAPORAN TERKINI
   ========================= */

$sql_recent = "SELECT *
               FROM items
               WHERE user_id='$user_id'
               ORDER BY created_at DESC
               LIMIT 5";

$result_recent = $mysqli->query($sql_recent);

?>

<!DOCTYPE html>
<html lang="ms">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard - LostLink</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #f5f7fa;
    color: #222;
}


/* =========================
   NAVBAR
   ========================= */

header {
    background: white;
    padding: 15px 7%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

.logo img {
    width: 145px;
    height: auto;
    display: block;
}

nav {
    display: flex;
    align-items: center;
    gap: 25px;
}

nav a {
    text-decoration: none;
    color: #333;
    font-size: 15px;
}

nav a:hover {
    color: #2563eb;
}

.logout {
    background: #2563eb;
    color: white !important;
    padding: 10px 18px;
    border-radius: 8px;
}

.logout:hover {
    background: #1d4ed8;
}


/* =========================
   MAIN
   ========================= */

.container {
    width: 85%;
    max-width: 1200px;
    margin: 40px auto;
}


/* =========================
   WELCOME
   ========================= */

.welcome {
    background: #eef5ff;
    padding: 30px;
    border-radius: 15px;
    margin-bottom: 30px;
}

.welcome h1 {
    font-size: 30px;
    margin-bottom: 10px;
    color: #1e3a8a;
}

.welcome p {
    color: #555;
}


/* =========================
   STAT CARDS
   ========================= */

.stats {
    display: flex;
    gap: 20px;
    margin-bottom: 35px;
}

.stat-card {
    background: white;
    flex: 1;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.06);
}

.stat-card h3 {
    font-size: 15px;
    color: #666;
    margin-bottom: 10px;
}

.stat-number {
    font-size: 32px;
    font-weight: bold;
    color: #2563eb;
}


/* =========================
   QUICK ACTION
   ========================= */

.section-title {
    margin-bottom: 20px;
    font-size: 23px;
}

.actions {
    display: flex;
    gap: 20px;
    margin-bottom: 40px;
}

.action-card {
    background: white;
    flex: 1;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.06);
}

.action-card h3 {
    margin-bottom: 10px;
}

.action-card p {
    color: #666;
    line-height: 1.5;
    margin-bottom: 20px;
}

.action-btn {
    display: inline-block;
    background: #2563eb;
    color: white;
    text-decoration: none;
    padding: 11px 18px;
    border-radius: 8px;
}

.action-btn:hover {
    background: #1d4ed8;
}

.found-btn {
    background: #16a34a;
}

.found-btn:hover {
    background: #15803d;
}

.search-btn {
    background: #7c3aed;
}

.search-btn:hover {
    background: #6d28d9;
}


/* =========================
   RECENT REPORTS
   ========================= */

.recent {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.06);
}

.report {
    border-bottom: 1px solid #eee;
    padding: 18px 0;
}

.report:last-child {
    border-bottom: none;
}

.report-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
}

.report h3 {
    font-size: 18px;
}

.report-info {
    color: #666;
    font-size: 14px;
    line-height: 1.6;
}

.badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.badge-pending {
    background: #fef3c7;
    color: #92400e;
}

.badge-found {
    background: #dcfce7;
    color: #166534;
}

.badge-claimed {
    background: #dbeafe;
    color: #1e40af;
}

.badge-closed {
    background: #e5e7eb;
    color: #374151;
}

.type-lost {
    color: #dc2626;
    font-weight: bold;
}

.type-found {
    color: #16a34a;
    font-weight: bold;
}

.view-btn {
    display: inline-block;
    margin-top: 10px;
    color: #2563eb;
    text-decoration: none;
    font-size: 14px;
    font-weight: bold;
}

.view-btn:hover {
    text-decoration: underline;
}


/* =========================
   EMPTY
   ========================= */

.empty {
    text-align: center;
    color: #777;
    padding: 30px;
}


/* =========================
   FOOTER
   ========================= */

footer {
    background: #111827;
    color: white;
    text-align: center;
    padding: 25px;
    margin-top: 50px;
}


/* =========================
   MOBILE
   ========================= */

@media(max-width: 800px) {

    header {
        padding: 15px 5%;
    }

    nav {
        gap: 10px;
    }

    nav a {
        font-size: 13px;
    }

    .container {
        width: 90%;
    }

    .stats {
        flex-direction: column;
    }

    .actions {
        flex-direction: column;
    }

    .report-top {
        align-items: flex-start;
        gap: 10px;
        flex-direction: column;
    }

}

</style>

</head>

<body>


<!-- =========================
     NAVBAR
     ========================= -->

<header>

    <a href="dashboard.php" class="logo">

        <img src="assets/lostlink-logo.png" alt="LostLink Logo">

    </a>


    <nav>

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="search.php">
            Cari Barang
        </a>

        <a href="my_reports.php">
            Laporan Saya
        </a>

        <a href="profile.php">
            Profil
        </a>

        <a href="logout.php" class="logout">
            Log Keluar
        </a>

    </nav>

</header>


<!-- =========================
     MAIN CONTENT
     ========================= -->

<div class="container">


    <!-- WELCOME -->

    <div class="welcome">

        <h1>
            Selamat Datang, <?php echo htmlspecialchars($name); ?> 👋
        </h1>

        <p>
            Selamat datang ke LostLink. 
            Urus dan semak laporan barang hilang atau dijumpai anda di sini.
        </p>

    </div>


    <!-- STATISTICS -->

    <div class="stats">

        <div class="stat-card">

            <h3>
                Jumlah Laporan
            </h3>

            <div class="stat-number">
                <?php echo $total_reports; ?>
            </div>

        </div>


        <div class="stat-card">

            <h3>
                Barang Hilang
            </h3>

            <div class="stat-number">
                <?php echo $total_lost; ?>
            </div>

        </div>


        <div class="stat-card">

            <h3>
                Barang Dijumpai
            </h3>

            <div class="stat-number">
                <?php echo $total_found; ?>
            </div>

        </div>

    </div>


    <!-- QUICK ACTION -->

    <h2 class="section-title">
        Apa yang anda ingin lakukan?
    </h2>


    <div class="actions">


        <div class="action-card">

            <h3>
                Laporan Barang Hilang
            </h3>

            <p>
                Laporkan barang anda yang hilang supaya
                pelajar lain dapat membantu mengenal pasti
                dan menjumpainya.
            </p>

            <a href="report_lost.php" class="action-btn">
                Buat Laporan
            </a>

        </div>


        <div class="action-card">

            <h3>
                Laporan Barang Dijumpai
            </h3>

            <p>
                Menjumpai barang milik pelajar lain?
                Laporkan barang tersebut supaya pemiliknya
                dapat membuat tuntutan.
            </p>

            <a href="report_found.php" class="action-btn found-btn">
                Lapor Barang
            </a>

        </div>


        <div class="action-card">

            <h3>
                Cari Barang
            </h3>

            <p>
                Cari senarai barang hilang dan dijumpai
                berdasarkan nama, kategori atau lokasi.
            </p>

            <a href="search.php" class="action-btn search-btn">
                Cari Sekarang
            </a>

        </div>


    </div>


    <!-- RECENT REPORTS -->

    <h2 class="section-title">
        Laporan Terkini Saya
    </h2>


    <div class="recent">

        <?php

        if ($result_recent->num_rows > 0) {

            while ($row = $result_recent->fetch_assoc()) {

        ?>

        <div class="report">

            <div class="report-top">

                <h3>
                    <?php echo htmlspecialchars($row['item_name']); ?>
                </h3>


                <?php

                if ($row['status'] == "Pending") {

                    echo "<span class='badge badge-pending'>Pending</span>";

                } elseif ($row['status'] == "Found") {

                    echo "<span class='badge badge-found'>Found</span>";

                } elseif ($row['status'] == "Claimed") {

                    echo "<span class='badge badge-claimed'>Claimed</span>";

                } else {

                    echo "<span class='badge badge-closed'>Closed</span>";

                }

                ?>

            </div>


            <div class="report-info">

                <span class="<?php

                if ($row['item_type'] == 'Lost') {

                    echo 'type-lost';

                } else {

                    echo 'type-found';

                }

                ?>">

                    <?php echo $row['item_type']; ?>

                </span>

                &nbsp; | &nbsp;

                <?php echo htmlspecialchars($row['category']); ?>

                &nbsp; | &nbsp;

                <?php echo htmlspecialchars($row['location']); ?>

                &nbsp; | &nbsp;

                <?php echo date("d/m/Y", strtotime($row['item_date'])); ?>

            </div>


            <a 
                href="item_details.php?id=<?php echo $row['item_id']; ?>" 
                class="view-btn"
            >
                Lihat Butiran →
            </a>

        </div>


        <?php

            }

        } else {

        ?>

        <div class="empty">

            Anda belum mempunyai sebarang laporan.

        </div>

        <?php

        }

        ?>

    </div>

</div>


<footer>

    © 2026 LostLink | Sistem Pengurusan Barang Hilang dan Dijumpai

</footer>


</body>

</html>