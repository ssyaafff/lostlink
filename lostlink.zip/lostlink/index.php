<?php
session_start();
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LostLink</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f5f7fa;
            color: #222;
        }

        header {
            background: white;
            padding: 15px 8%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ddd;
        }

        /* LOGO NAVBAR */
        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .logo img {
            width: 145px;
            height: auto;
            display: block;
        }

        nav {
            display: flex;
            align-items: center;
        }

        nav a {
            text-decoration: none;
            color: #333;
            margin-left: 25px;
        }

        nav a:hover {
            color: #2563eb;
        }

        .login-btn {
            background: #2563eb;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
        }

        .login-btn:hover {
            background: #1d4ed8;
            color: white;
        }

        /* HERO */
        .hero {
            min-height: 520px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 60px 8%;
            background: #eef5ff;
        }

        .hero-text {
            width: 50%;
        }

        .hero h1 {
            font-size: 48px;
            margin-bottom: 20px;
            line-height: 1.2;
        }

        .hero h1 span {
            color: #2563eb;
        }

        .hero p {
            font-size: 18px;
            line-height: 1.6;
            color: #555;
            margin-bottom: 30px;
            max-width: 600px;
        }

        .hero-btn {
            display: inline-block;
            background: #2563eb;
            color: white;
            text-decoration: none;
            padding: 14px 25px;
            border-radius: 8px;
        }

        .hero-btn:hover {
            background: #1d4ed8;
        }

        /* HERO LOGO */
        .hero-box {
            width: 380px;
            height: 300px;
            background: white;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            padding: 30px;
        }

        .hero-box img {
            width: 280px;
            max-width: 100%;
            height: auto;
            display: block;
        }

        /* FEATURES */
        .features {
            padding: 60px 8%;
            text-align: center;
        }

        .features h2 {
            margin-bottom: 35px;
            font-size: 30px;
        }

        .cards {
            display: flex;
            gap: 25px;
            justify-content: center;
        }

        .card {
            background: white;
            width: 280px;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.06);
        }

        .card h3 {
            margin-bottom: 12px;
        }

        .card p {
            color: #666;
            line-height: 1.5;
        }

        /* FOOTER */
        footer {
            background: #111827;
            color: white;
            text-align: center;
            padding: 25px;
            margin-top: 30px;
        }

        /* RESPONSIVE */
        @media(max-width: 800px) {

            header {
                padding: 15px 5%;
            }

            .logo img {
                width: 120px;
            }

            nav a {
                margin-left: 12px;
                font-size: 14px;
            }

            .hero {
                flex-direction: column;
                gap: 40px;
                text-align: center;
                padding: 50px 5%;
            }

            .hero-text {
                width: 100%;
            }

            .hero h1 {
                font-size: 38px;
            }

            .hero p {
                margin-left: auto;
                margin-right: auto;
            }

            .hero-box {
                width: 100%;
                max-width: 380px;
            }

            .cards {
                flex-direction: column;
                align-items: center;
            }

            .card {
                width: 100%;
                max-width: 350px;
            }
        }
    </style>
</head>

<body>

<header>

    <!-- LOGO -->
    <a href="index.php" class="logo">
        <img src="assets/lostlink-logo.png" alt="LostLink">
    </a>

    <nav>
        <a href="index.php">Home</a>
        <a href="#about">Tentang</a>
        <a href="login.php" class="login-btn">Log Masuk</a>
    </nav>

</header>


<section class="hero">

    <div class="hero-text">

        <h1>
            Barang Hilang?<br>
            <span>LostLink</span> Membantu.
        </h1>

        <p>
            Platform untuk pelajar asrama lelaki melaporkan,
            mencari dan mendapatkan semula barang yang hilang
            atau dijumpai dengan lebih mudah.
        </p>

        <a href="register.php" class="hero-btn">
            Mula Sekarang
        </a>

    </div>


    <!-- LOGO BESAR -->
    <div class="hero-box">

        <img src="assets/lostlink-logo.png" alt="LostLink Logo">

    </div>

</section>


<section class="features" id="about">

    <h2>Kenapa LostLink?</h2>

    <div class="cards">

        <div class="card">

            <h3>Mudah Dicari</h3>

            <p>
                Cari maklumat barang hilang dan dijumpai
                dengan lebih cepat.
            </p>

        </div>


        <div class="card">

            <h3>Laporan</h3>

            <p>
                Buat laporan barang hilang atau dijumpai
                melalui satu sistem.
            </p>

        </div>


        <div class="card">

            <h3>Teratur</h3>

            <p>
                Semua rekod disimpan dalam sistem secara
                lebih tersusun.
            </p>

        </div>

    </div>

</section>


<footer>

    © 2026 LostLink | Sistem Pengurusan Barang Hilang dan Dijumpai

</footer>

</body>
</html>