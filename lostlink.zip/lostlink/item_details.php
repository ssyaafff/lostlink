<?php

session_start();
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if (!isset($_GET['id'])) {
    header("Location: search.php");
    exit();
}

$item_id = intval($_GET['id']);

$sql = "
    SELECT items.*, users.name
    FROM items
    INNER JOIN users ON items.user_id = users.user_id
    WHERE items.item_id = '$item_id'
";

$result = $mysqli->query($sql);

if ($result->num_rows == 0) {
    echo "
    <!DOCTYPE html>
    <html>
    <head>
        <title>Barang Tidak Dijumpai</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: #f5f8fc;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                margin: 0;
            }

            .box {
                background: white;
                padding: 40px;
                border-radius: 15px;
                text-align: center;
                box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            }

            .box h2 {
                color: #1e3a8a;
                margin-bottom: 10px;
            }

            .box p {
                color: #666;
                margin-bottom: 25px;
            }

            .btn {
                display: inline-block;
                padding: 12px 20px;
                background: #2563eb;
                color: white;
                text-decoration: none;
                border-radius: 8px;
            }
        </style>
    </head>

    <body>

        <div class='box'>
            <h2>Barang Tidak Dijumpai</h2>
            <p>Maklumat barang yang anda cari tidak wujud.</p>
            <a href='search.php' class='btn'>Kembali ke Carian</a>
        </div>

    </body>
    </html>
    ";
    exit();
}

$item = $result->fetch_assoc();

$item_type = $item['item_type'];
$status = $item['status'];

$is_owner = false;

if ($item['user_id'] == $user_id) {
    $is_owner = true;
}

$can_claim = false;

if ($item_type == "Found" && $is_owner == false) {

    if ($status != "Claimed" && $status != "Closed") {
        $can_claim = true;
    }
}

?>

<!DOCTYPE html>
<html lang="ms">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Detail Barang - LostLink</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f5f8fc;
            color: #1f2937;
        }

        /* ================= NAVBAR ================= */

        .navbar {
            width: 100%;
            min-height: 75px;
            background: white;
            display: flex;
            align-items: center;
            padding: 0 6%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }

        .logo {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }

        .logo img {
            width: 150px;
            height: auto;
            display: block;
        }

        .nav-links {
            margin-left: auto;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
            white-space: nowrap;
        }

        .nav-links a {
            text-decoration: none;
            color: #374151;
            font-size: 14px;
            font-weight: 600;
        }

        .nav-links a:hover {
            color: #2563eb;
        }

        .logout {
            background: #ef4444;
            color: white !important;
            padding: 9px 15px;
            border-radius: 7px;
        }

        .logout:hover {
            background: #dc2626;
        }

        /* ================= CONTAINER ================= */

        .container {
            width: 90%;
            max-width: 1100px;
            margin: 40px auto;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #2563eb;
            text-decoration: none;
            font-weight: 600;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        /* ================= DETAIL CARD ================= */

        .detail-card {
            background: white;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.07);
            display: grid;
            grid-template-columns: 45% 55%;
        }

        .image-section {
            background: #eef4ff;
            min-height: 450px;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 30px;
        }

        .image-section img {
            width: 100%;
            max-height: 420px;
            object-fit: contain;
            border-radius: 12px;
        }

        .no-image {
            text-align: center;
            color: #94a3b8;
            font-size: 16px;
        }

        .info-section {
            padding: 40px;
        }

        .item-type {
            display: inline-block;
            padding: 7px 13px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .lost {
            background: #fee2e2;
            color: #b91c1c;
        }

        .found {
            background: #dcfce7;
            color: #15803d;
        }

        .item-title {
            font-size: 30px;
            color: #111827;
            margin-bottom: 25px;
        }

        .status {
            display: inline-block;
            padding: 7px 13px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 25px;
        }

        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }

        .status-found {
            background: #dcfce7;
            color: #166534;
        }

        .status-claimed {
            background: #dbeafe;
            color: #1d4ed8;
        }

        .status-closed {
            background: #e5e7eb;
            color: #4b5563;
        }

        /* ================= INFO ================= */

        .info-list {
            display: flex;
            flex-direction: column;
            gap: 18px;
            margin-bottom: 25px;
        }

        .info-row {
            display: flex;
            gap: 15px;
        }

        .info-label {
            width: 120px;
            font-weight: bold;
            color: #64748b;
            flex-shrink: 0;
        }

        .info-value {
            color: #1f2937;
        }

        .description {
            margin-top: 25px;
            padding-top: 25px;
            border-top: 1px solid #e5e7eb;
        }

        .description h3 {
            font-size: 17px;
            margin-bottom: 10px;
            color: #111827;
        }

        .description p {
            line-height: 1.7;
            color: #4b5563;
            white-space: pre-line;
        }

        /* ================= BUTTON ================= */

        .action-area {
            margin-top: 30px;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .btn {
            display: inline-block;
            padding: 12px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }

        .btn-primary {
            background: #2563eb;
            color: white;
        }

        .btn-primary:hover {
            background: #1d4ed8;
        }

        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }

        .btn-secondary:hover {
            background: #d1d5db;
        }

        .owner-box {
            margin-top: 25px;
            background: #eff6ff;
            color: #1d4ed8;
            padding: 13px 15px;
            border-radius: 8px;
            font-size: 14px;
        }

        .success-message {
            background: #dcfce7;
            color: #166534;
            padding: 14px 18px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        /* ================= RESPONSIVE ================= */

        @media (max-width: 800px) {

            .detail-card {
                grid-template-columns: 1fr;
            }

            .image-section {
                min-height: 300px;
            }

            .info-section {
                padding: 30px;
            }

            .item-title {
                font-size: 25px;
            }

        }

        @media (max-width: 750px) {

            .navbar {
                padding: 15px 5%;
                flex-direction: column;
                gap: 15px;
            }

            .nav-links {
                margin-left: 0;
                justify-content: center;
                flex-wrap: wrap;
                gap: 12px;
            }

        }

        @media (max-width: 450px) {

            .container {
                width: 94%;
                margin: 25px auto;
            }

            .info-section {
                padding: 22px;
            }

            .info-row {
                flex-direction: column;
                gap: 4px;
            }

            .info-label {
                width: auto;
            }

            .item-title {
                font-size: 22px;
            }

        }

    </style>

</head>

<body>

    <!-- NAVBAR -->

    <nav class="navbar">

        <a href="dashboard.php" class="logo">
            <img src="assets/lostlink-logo.png" alt="LostLink Logo">
        </a>

        <div class="nav-links">

            <a href="dashboard.php">Dashboard</a>

            <a href="search.php">Cari Barang</a>

            <a href="my_reports.php">Laporan Saya</a>

            <a href="profile.php">Profil</a>

            <a href="logout.php" class="logout">Log Keluar</a>

        </div>

    </nav>


    <!-- MAIN -->

    <div class="container">

        <a href="search.php" class="back-link">
            ← Kembali ke Carian
        </a>


        <?php

        if (isset($_GET['claim'])) {

            if ($_GET['claim'] == "success") {

                echo "
                <div class='success-message'>
                    Permohonan tuntutan berjaya dihantar. Sila tunggu semakan daripada admin.
                </div>
                ";

            }

        }

        ?>


        <div class="detail-card">


            <!-- IMAGE -->

            <div class="image-section">

                <?php

                if (!empty($item['image'])) {

                    echo "
                    <img src='uploads/items/" . htmlspecialchars($item['image']) . "' alt='Gambar Barang'>
                    ";

                } else {

                    echo "
                    <div class='no-image'>
                        Tiada gambar barang
                    </div>
                    ";

                }

                ?>

            </div>


            <!-- INFORMATION -->

            <div class="info-section">


                <?php

                if ($item_type == "Lost") {

                    echo "<span class='item-type lost'>BARANG HILANG</span>";

                } else {

                    echo "<span class='item-type found'>BARANG DIJUMPAI</span>";

                }

                ?>


                <h1 class="item-title">
                    <?php echo htmlspecialchars($item['item_name']); ?>
                </h1>


                <?php

                if ($status == "Pending") {

                    echo "<span class='status status-pending'>Pending</span>";

                } elseif ($status == "Found") {

                    echo "<span class='status status-found'>Dijumpai</span>";

                } elseif ($status == "Claimed") {

                    echo "<span class='status status-claimed'>Dituntut</span>";

                } elseif ($status == "Closed") {

                    echo "<span class='status status-closed'>Ditutup</span>";

                }

                ?>


                <div class="info-list">

                    <div class="info-row">

                        <div class="info-label">
                            Kategori
                        </div>

                        <div class="info-value">
                            <?php echo htmlspecialchars($item['category']); ?>
                        </div>

                    </div>


                    <div class="info-row">

                        <div class="info-label">
                            Lokasi
                        </div>

                        <div class="info-value">
                            <?php echo htmlspecialchars($item['location']); ?>
                        </div>

                    </div>


                    <div class="info-row">

                        <div class="info-label">
                            Tarikh
                        </div>

                        <div class="info-value">
                            <?php echo htmlspecialchars($item['item_date']); ?>
                        </div>

                    </div>


                    <div class="info-row">

                        <div class="info-label">
                            Dilaporkan Oleh
                        </div>

                        <div class="info-value">
                            <?php echo htmlspecialchars($item['name']); ?>
                        </div>

                    </div>

                </div>


                <div class="description">

                    <h3>
                        Penerangan
                    </h3>

                    <?php

                    if (!empty($item['description'])) {

                        echo "<p>" . htmlspecialchars($item['description']) . "</p>";

                    } else {

                        echo "<p>Tiada penerangan diberikan.</p>";

                    }

                    ?>

                </div>


                <!-- ACTION -->

                <div class="action-area">

                    <a href="search.php" class="btn btn-secondary">
                        Kembali
                    </a>


                    <?php

                    if ($can_claim == true) {

                        echo "
                        <a href='claim.php?id=" . $item_id . "' class='btn btn-primary'>
                            Tuntut Barang
                        </a>
                        ";

                    }

                    ?>

                </div>


                <?php

                if ($is_owner == true) {

                    echo "
                    <div class='owner-box'>
                        Ini adalah laporan yang anda hantar.
                    </div>
                    ";

                }

                ?>


            </div>

        </div>

    </div>

</body>

</html>