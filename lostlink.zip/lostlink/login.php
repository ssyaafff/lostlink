<?php

session_start();
include "config.php";

$message = "";

if (isset($_POST['login'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email'";

    $result = $mysqli->query($sql);

    if ($result->num_rows == 1) {

        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {

            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            if ($user['role'] == "admin") {

                header("Location: admin/dashboard.php");

            } else {

                header("Location: dashboard.php");

            }

            exit;

        } else {

            $message = "Email atau password salah.";

        }

    } else {

        $message = "Email atau password salah.";

    }
}

?>

<!DOCTYPE html>
<html lang="ms">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Log Masuk - LostLink</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #eef5ff;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* LOGIN BOX */

.login-box {
    background: white;
    width: 400px;
    padding: 35px;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

/* LOGO */

.logo {
    text-align: center;
    margin-bottom: 10px;
}

.logo img {
    width: 180px;
    height: auto;
    display: block;
    margin: auto;
}

/* SUBTITLE */

.subtitle {
    text-align: center;
    color: #666;
    margin: 10px 0 25px;
}

/* INPUT */

input {
    width: 100%;
    padding: 13px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 14px;
    outline: none;
}

input:focus {
    border-color: #2563eb;
}

/* BUTTON */

button {
    width: 100%;
    padding: 13px;
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background: #1d4ed8;
}

/* ERROR MESSAGE */

.message {
    background: #fee2e2;
    color: #b91c1c;
    padding: 10px;
    border-radius: 7px;
    text-align: center;
    margin-bottom: 15px;
}

/* REGISTER */

.register {
    text-align: center;
    margin-top: 20px;
    color: #555;
}

.register a {
    color: #2563eb;
    text-decoration: none;
    font-weight: bold;
}

.register a:hover {
    text-decoration: underline;
}

/* SUCCESS MESSAGE */

.success {
    background: #dcfce7;
    color: #15803d;
    padding: 10px;
    border-radius: 7px;
    margin-bottom: 15px;
    text-align: center;
}

/* MOBILE */

@media(max-width: 500px) {

    .login-box {
        width: 90%;
        padding: 25px;
    }

    .logo img {
        width: 150px;
    }

}

</style>

</head>

<body>

<div class="login-box">

    <!-- LOGO -->
    <div class="logo">
        <img src="assets/lostlink-logo.png" alt="LostLink Logo">
    </div>

    <div class="subtitle">
        Log Masuk Pelajar
    </div>


    <?php

    if ($message != "") {
        echo "<div class='message'>$message</div>";
    }

    if (isset($_GET['registered'])) {
        echo "<div class='success'>Pendaftaran berjaya. Sila log masuk.</div>";
    }

    ?>


    <form method="POST">

        <input 
            type="email" 
            name="email" 
            placeholder="Email" 
            required
        >

        <input 
            type="password" 
            name="password" 
            placeholder="Password" 
            required
        >

        <button type="submit" name="login">
            Log Masuk
        </button>

    </form>


    <div class="register">

        Belum mempunyai akaun?

        <a href="register.php">
            Daftar sekarang
        </a>

    </div>

</div>

</body>

</html>