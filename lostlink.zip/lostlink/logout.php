<?php

session_start();

// Kosongkan semua data session
$_SESSION = array();

// Hapuskan session
session_destroy();

// Kembali ke halaman login
header("Location: login.php");
exit();

?>