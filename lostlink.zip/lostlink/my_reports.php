<?php

session_start();
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

/* =========================
   GET USER REPORTS
========================= */

$sql = "
    SELECT *
    FROM items
    WHERE user_id = '$user_id'
    ORDER BY created_at DESC
";

$result = $mysqli->query($sql);

?>

<!DOCTYPE html>
<html lang="ms">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Laporan Saya - LostLink</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f5f7fa;
            color: #1f2937;
        }


        /* =========================
           NAVBAR
        ========================= */

        .navbar {
            width: 100%;
            min-height: 75px;
            background: white;

            display: flex;
            align-items: center;

            padding: 0 6%;

            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);

            position: relative;
            z-index: 100;
        }

        .logo {
            display: flex;
            align-items: center;

            text-decoration: none;

            flex-shrink: 0;
        }

        .logo img {
            width: 150px;
            height: auto;
            display: block;
        }

        .nav-links {
            margin-left: auto;

            display: flex;
            align-items: center;
            justify-content: flex-end;

            gap: 20px;

            white-space: nowrap;
        }

        .nav-links a {
            text-decoration: none;

            color: #374151;

            font-size: 14px;
            font-weight: bold;

            display: flex;
            align-items: center;

            padding: 8px 0;
        }

        .nav-links a:hover {
            color: #2563eb;
        }

        .nav-links .logout {
            background: #2563eb;

            color: white !important;

            padding: 10px 17px;

            border-radius: 8px;
        }

        .nav-links .logout:hover {
            background: #1d4ed8;
        }


        /* =========================
           CONTAINER
        ========================= */

        .container {
            width: 86%;
            max-width: 1200px;

            margin: 40px auto;
        }


        /* =========================
           PAGE HEADER
        ========================= */

        .page-header {
            margin-bottom: 25px;
        }

        .page-header h1 {
            font-size: 30px;

            color: #111827;

            margin-bottom: 8px;
        }

        .page-header p {
            color: #6b7280;

            font-size: 15px;
        }


        /* =========================
           SUCCESS MESSAGE
        ========================= */

        .success-message {
            background: #dcfce7;

            color: #166534;

            padding: 14px 18px;

            border-radius: 10px;

            margin-bottom: 20px;

            font-size: 14px;

            border: 1px solid #bbf7d0;
        }


        /* =========================
           REPORT CARD
        ========================= */

        .report-list {
            display: flex;

            flex-direction: column;

            gap: 18px;
        }

        .report-card {
            background: white;

            border-radius: 15px;

            padding: 20px;

            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);

            display: flex;

            gap: 20px;

            align-items: center;
        }


        /* =========================
           IMAGE
        ========================= */

        .report-image {
            width: 150px;

            height: 120px;

            background: #eef2f7;

            border-radius: 10px;

            overflow: hidden;

            flex-shrink: 0;

            display: flex;

            align-items: center;

            justify-content: center;
        }

        .report-image img {
            width: 100%;

            height: 100%;

            object-fit: cover;
        }

        .no-image {
            color: #9ca3af;

            font-size: 13px;

            text-align: center;
        }


        /* =========================
           REPORT CONTENT
        ========================= */

        .report-content {
            flex: 1;
        }

        .report-content h2 {
            font-size: 20px;

            color: #111827;

            margin-bottom: 10px;
        }

        .report-info {
            display: grid;

            grid-template-columns: repeat(2, 1fr);

            gap: 7px 20px;

            margin-bottom: 12px;
        }

        .report-info p {
            color: #6b7280;

            font-size: 13px;
        }


        /* =========================
           BADGES
        ========================= */

        .badges {
            display: flex;

            gap: 8px;

            flex-wrap: wrap;

            margin-bottom: 10px;
        }

        .badge {
            display: inline-block;

            padding: 5px 10px;

            border-radius: 20px;

            font-size: 11px;

            font-weight: bold;
        }

        .badge-lost {
            background: #fee2e2;

            color: #b91c1c;
        }

        .badge-found {
            background: #dcfce7;

            color: #15803d;
        }

        .badge-pending {
            background: #fef3c7;

            color: #92400e;
        }

        .badge-claimed {
            background: #dbeafe;

            color: #1d4ed8;
        }

        .badge-closed {
            background: #e5e7eb;

            color: #4b5563;
        }


        /* =========================
           BUTTON
        ========================= */

        .report-action {
            width: 150px;

            flex-shrink: 0;
        }

        .detail-btn {
            display: block;

            width: 100%;

            text-align: center;

            text-decoration: none;

            background: #2563eb;

            color: white;

            padding: 11px;

            border-radius: 8px;

            font-size: 13px;

            font-weight: bold;
        }

        .detail-btn:hover {
            background: #1d4ed8;
        }


        /* =========================
           EMPTY
        ========================= */

        .empty-box {
            background: white;

            padding: 60px 20px;

            border-radius: 15px;

            text-align: center;

            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        .empty-icon {
            font-size: 45px;

            margin-bottom: 15px;
        }

        .empty-box h2 {
            color: #374151;

            font-size: 21px;

            margin-bottom: 8px;
        }

        .empty-box p {
            color: #6b7280;

            font-size: 14px;

            margin-bottom: 20px;
        }

        .new-report-btn {
            display: inline-block;

            text-decoration: none;

            background: #2563eb;

            color: white;

            padding: 11px 20px;

            border-radius: 8px;

            font-size: 13px;

            font-weight: bold;
        }

        .new-report-btn:hover {
            background: #1d4ed8;
        }


        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 1000px) {

            .navbar {
                padding: 0 4%;
            }

            .nav-links {
                gap: 14px;
            }

            .nav-links a {
                font-size: 13px;
            }

        }


        @media (max-width: 750px) {

            .navbar {
                min-height: 75px;

                height: auto;

                padding: 15px 5%;

                flex-direction: column;

                gap: 15px;
            }

            .logo {
                width: 100%;

                justify-content: center;
            }

            .nav-links {
                width: 100%;

                margin-left: 0;

                display: flex;

                align-items: center;

                justify-content: center;

                flex-wrap: wrap;

                gap: 10px 15px;

                white-space: normal;
            }

            .nav-links a {
                font-size: 13px;

                padding: 6px 0;
            }

            .nav-links .logout {
                padding: 9px 15px;
            }

            .container {
                width: 92%;

                margin: 25px auto;
            }

            .report-card {
                flex-direction: column;

                align-items: stretch;
            }

            .report-image {
                width: 100%;

                height: 200px;
            }

            .report-info {
                grid-template-columns: 1fr;
            }

            .report-action {
                width: 100%;
            }

        }


        @media (max-width: 450px) {

            .nav-links {
                gap: 8px 12px;
            }

            .nav-links a {
                font-size: 12px;
            }

            .nav-links .logout {
                padding: 8px 12px;
            }

            .page-header h1 {
                font-size: 25px;
            }

        }

    </style>

</head>

<body>


<!-- =========================
     NAVBAR
========================= -->

<div class="navbar">

    <a href="dashboard.php" class="logo">

        <img
            src="assets/lostlink-logo.png"
            alt="LostLink Logo"
        >

    </a>


    <div class="nav-links">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="search.php">
            Cari Barang
        </a>

        <a href="my_reports.php">
            Laporan Saya
        </a>

        <a href="profile.php">
            Profil
        </a>

        <a href="logout.php" class="logout">
            Log Keluar
        </a>

    </div>

</div>


<!-- =========================
     MAIN
========================= -->

<div class="container">


    <div class="page-header">

        <h1>
            Laporan Saya
        </h1>

        <p>
            Lihat dan semak semua laporan barang yang telah anda hantar.
        </p>

    </div>


    <!-- =========================
         SUCCESS MESSAGE
    ========================= -->

    <?php

    if (isset($_GET['success'])) {

        if ($_GET['success'] == "lost") {

            ?>

            <div class="success-message">
                Laporan barang hilang berjaya dihantar.
            </div>

            <?php

        }

        if ($_GET['success'] == "found") {

            ?>

            <div class="success-message">
                Laporan barang dijumpai berjaya dihantar.
            </div>

            <?php

        }

    }

    ?>


    <!-- =========================
         REPORT LIST
    ========================= -->

    <?php

    if ($result->num_rows > 0) {

        ?>

        <div class="report-list">

        <?php

        while ($row = $result->fetch_assoc()) {

            ?>

            <div class="report-card">


                <!-- IMAGE -->

                <div class="report-image">

                    <?php

                    if (!empty($row['image'])) {

                        ?>

                        <img
                            src="uploads/items/<?php echo htmlspecialchars($row['image']); ?>"
                            alt="Gambar barang"
                        >

                        <?php

                    } else {

                        ?>

                        <div class="no-image">
                            Tiada gambar
                        </div>

                        <?php

                    }

                    ?>

                </div>


                <!-- CONTENT -->

                <div class="report-content">


                    <div class="badges">

                        <?php

                        if ($row['item_type'] == "Lost") {

                            ?>

                            <span class="badge badge-lost">
                                BARANG HILANG
                            </span>

                            <?php

                        } else {

                            ?>

                            <span class="badge badge-found">
                                BARANG DIJUMPAI
                            </span>

                            <?php

                        }


                        if ($row['status'] == "Pending") {

                            ?>

                            <span class="badge badge-pending">
                                Pending
                            </span>

                            <?php

                        } elseif ($row['status'] == "Found") {

                            ?>

                            <span class="badge badge-found">
                                Dijumpai
                            </span>

                            <?php

                        } elseif ($row['status'] == "Claimed") {

                            ?>

                            <span class="badge badge-claimed">
                                Dituntut
                            </span>

                            <?php

                        } else {

                            ?>

                            <span class="badge badge-closed">
                                Ditutup
                            </span>

                            <?php

                        }

                        ?>

                    </div>


                    <h2>

                        <?php

                        echo htmlspecialchars($row['item_name']);

                        ?>

                    </h2>


                    <div class="report-info">

                        <p>
                            📁 Kategori:
                            <?php
                            echo htmlspecialchars($row['category']);
                            ?>
                        </p>

                        <p>
                            📍 Lokasi:
                            <?php
                            echo htmlspecialchars($row['location']);
                            ?>
                        </p>

                        <p>
                            📅 Tarikh:
                            <?php
                            echo date(
                                "d/m/Y",
                                strtotime($row['item_date'])
                            );
                            ?>
                        </p>

                        <p>
                            🕒 Dilaporkan:
                            <?php
                            echo date(
                                "d/m/Y H:i",
                                strtotime($row['created_at'])
                            );
                            ?>
                        </p>

                    </div>

                </div>


                <!-- ACTION -->

                <div class="report-action">

                    <a
                        href="item_details.php?id=<?php echo $row['item_id']; ?>"
                        class="detail-btn"
                    >
                        Lihat Butiran
                    </a>

                </div>

            </div>

            <?php

        }

        ?>

        </div>

        <?php

    } else {

        ?>

        <div class="empty-box">

            <div class="empty-icon">
                📦
            </div>

            <h2>
                Belum Ada Laporan
            </h2>

            <p>
                Anda belum membuat sebarang laporan barang hilang atau dijumpai.
            </p>

            <a
                href="report_lost.php"
                class="new-report-btn"
            >
                + Lapor Barang Hilang
            </a>

        </div>

        <?php

    }

    ?>

</div>

</body>

</html>