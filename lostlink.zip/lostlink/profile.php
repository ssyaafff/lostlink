<?php

session_start();
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];


// =====================================================
// DAPATKAN MAKLUMAT USER
// =====================================================

$sql = "
    SELECT *
    FROM users
    WHERE user_id = '$user_id'
";

$result = $mysqli->query($sql);

if ($result->num_rows == 0) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$user = $result->fetch_assoc();


// =====================================================
// STATISTIK USER
// =====================================================

$total_query = "
    SELECT COUNT(*) AS total
    FROM items
    WHERE user_id = '$user_id'
";

$total_result = $mysqli->query($total_query);
$total_data = $total_result->fetch_assoc();
$total_reports = $total_data['total'];


$lost_query = "
    SELECT COUNT(*) AS total
    FROM items
    WHERE user_id = '$user_id'
    AND item_type = 'Lost'
";

$lost_result = $mysqli->query($lost_query);
$lost_data = $lost_result->fetch_assoc();
$total_lost = $lost_data['total'];


$found_query = "
    SELECT COUNT(*) AS total
    FROM items
    WHERE user_id = '$user_id'
    AND item_type = 'Found'
";

$found_result = $mysqli->query($found_query);
$found_data = $found_result->fetch_assoc();
$total_found = $found_data['total'];


$claim_query = "
    SELECT COUNT(*) AS total
    FROM claims
    WHERE user_id = '$user_id'
";

$claim_result = $mysqli->query($claim_query);
$claim_data = $claim_result->fetch_assoc();
$total_claims = $claim_data['total'];


// =====================================================
// MESEJ
// =====================================================

$success = "";
$error = "";


// =====================================================
// UPDATE PROFILE
// =====================================================

if (isset($_POST['update_profile'])) {

    $name = trim($_POST['name']);
    $matric_no = trim($_POST['matric_no']);
    $email = trim($_POST['email']);

    if ($name == "" || $matric_no == "" || $email == "") {

        $error = "Sila lengkapkan semua maklumat.";

    } else {

        $name = $mysqli->real_escape_string($name);
        $matric_no = $mysqli->real_escape_string($matric_no);
        $email = $mysqli->real_escape_string($email);

        // Semak email digunakan oleh orang lain

        $check_email = "
            SELECT user_id
            FROM users
            WHERE email = '$email'
            AND user_id != '$user_id'
        ";

        $email_result = $mysqli->query($check_email);

        if ($email_result->num_rows > 0) {

            $error = "Email tersebut sudah digunakan oleh pengguna lain.";

        } else {

            $update_sql = "
                UPDATE users
                SET
                    name = '$name',
                    matric_no = '$matric_no',
                    email = '$email'
                WHERE user_id = '$user_id'
            ";

            if ($mysqli->query($update_sql)) {

                $_SESSION['name'] = $name;

                $success = "Maklumat profil berjaya dikemas kini.";

                // Ambil data terbaru

                $sql = "
                    SELECT *
                    FROM users
                    WHERE user_id = '$user_id'
                ";

                $result = $mysqli->query($sql);
                $user = $result->fetch_assoc();

            } else {

                $error = "Maklumat profil gagal dikemas kini.";

            }

        }

    }

}


// =====================================================
// TUKAR PASSWORD
// =====================================================

if (isset($_POST['change_password'])) {

    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];


    if (
        $current_password == "" ||
        $new_password == "" ||
        $confirm_password == ""
    ) {

        $error = "Sila lengkapkan semua ruangan password.";

    } elseif (!password_verify($current_password, $user['password'])) {

        $error = "Password semasa tidak betul.";

    } elseif ($new_password != $confirm_password) {

        $error = "Password baru dan pengesahan password tidak sama.";

    } elseif (strlen($new_password) < 6) {

        $error = "Password baru mestilah sekurang-kurangnya 6 aksara.";

    } else {

        $new_password_hash = password_hash(
            $new_password,
            PASSWORD_DEFAULT
        );

        $update_password = "
            UPDATE users
            SET password = '$new_password_hash'
            WHERE user_id = '$user_id'
        ";

        if ($mysqli->query($update_password)) {

            $success = "Password berjaya ditukar.";

            // Ambil password terbaru

            $sql = "
                SELECT *
                FROM users
                WHERE user_id = '$user_id'
            ";

            $result = $mysqli->query($sql);
            $user = $result->fetch_assoc();

        } else {

            $error = "Password gagal ditukar.";

        }

    }

}

?>

<!DOCTYPE html>
<html lang="ms">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Profil - LostLink</title>


    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }


        body {
            font-family: Arial, sans-serif;
            background: #f5f8fc;
            color: #1f2937;
        }


        /* =====================================================
           NAVBAR
        ===================================================== */

        .navbar {
            width: 100%;
            min-height: 75px;
            background: white;
            display: flex;
            align-items: center;
            padding: 0 6%;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
        }


        .logo {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }


        .logo img {
            width: 150px;
            height: auto;
            display: block;
        }


        .nav-links {
            margin-left: auto;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 20px;
            white-space: nowrap;
        }


        .nav-links a {
            text-decoration: none;
            color: #374151;
            font-size: 14px;
            font-weight: 600;
        }


        .nav-links a:hover {
            color: #2563eb;
        }


        .logout {
            background: #ef4444;
            color: white !important;
            padding: 9px 15px;
            border-radius: 7px;
        }


        .logout:hover {
            background: #dc2626 !important;
        }


        /* =====================================================
           CONTAINER
        ===================================================== */

        .container {
            width: 90%;
            max-width: 1000px;
            margin: 40px auto;
        }


        /* =====================================================
           PROFILE HEADER
        ===================================================== */

        .profile-header {
            background: linear-gradient(
                135deg,
                #2563eb,
                #1d4ed8
            );

            color: white;
            padding: 30px;
            border-radius: 18px;
            margin-bottom: 25px;
        }


        .profile-header h1 {
            font-size: 28px;
            margin-bottom: 7px;
        }


        .profile-header p {
            opacity: 0.9;
        }


        /* =====================================================
           MESSAGE
        ===================================================== */

        .success {
            background: #dcfce7;
            color: #166534;
            padding: 14px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }


        .error {
            background: #fee2e2;
            color: #b91c1c;
            padding: 14px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }


        /* =====================================================
           STATS
        ===================================================== */

        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 25px;
        }


        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 14px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }


        .stat-title {
            color: #64748b;
            font-size: 13px;
            margin-bottom: 8px;
        }


        .stat-number {
            color: #1e3a8a;
            font-size: 27px;
            font-weight: bold;
        }


        /* =====================================================
           CARD
        ===================================================== */

        .card {
            background: white;
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }


        .card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #111827;
        }


        /* =====================================================
           FORM
        ===================================================== */

        .form-group {
            margin-bottom: 18px;
        }


        .form-group label {
            display: block;
            font-weight: bold;
            font-size: 14px;
            color: #374151;
            margin-bottom: 7px;
        }


        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
        }


        .form-group input:focus {
            border-color: #2563eb;
        }


        .form-group input:disabled {
            background: #f1f5f9;
            color: #64748b;
        }


        .help-text {
            margin-top: 6px;
            color: #94a3b8;
            font-size: 12px;
        }


        /* =====================================================
           BUTTON
        ===================================================== */

        .btn {
            display: inline-block;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }


        .btn-primary {
            background: #2563eb;
            color: white;
        }


        .btn-primary:hover {
            background: #1d4ed8;
        }


        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }


        .btn-secondary:hover {
            background: #d1d5db;
        }


        /* =====================================================
           ACCOUNT INFO
        ===================================================== */

        .account-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }


        .info-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 16px;
            border-radius: 10px;
        }


        .info-label {
            font-size: 12px;
            color: #64748b;
            margin-bottom: 5px;
        }


        .info-value {
            font-size: 15px;
            font-weight: bold;
            color: #1f2937;
        }


        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 800px) {

            .stats {
                grid-template-columns: repeat(2, 1fr);
            }

        }


        @media (max-width: 750px) {

            .navbar {
                padding: 15px 5%;
                flex-direction: column;
                gap: 15px;
            }


            .nav-links {
                margin-left: 0;
                justify-content: center;
                flex-wrap: wrap;
                gap: 12px;
            }

        }


        @media (max-width: 550px) {

            .container {
                width: 94%;
                margin: 25px auto;
            }


            .stats {
                grid-template-columns: 1fr;
            }


            .account-info {
                grid-template-columns: 1fr;
            }


            .card {
                padding: 22px;
            }


            .profile-header {
                padding: 23px;
            }


            .profile-header h1 {
                font-size: 23px;
            }

        }

    </style>

</head>


<body>


    <!-- =====================================================
         NAVBAR
    ===================================================== -->

    <nav class="navbar">

        <a href="dashboard.php" class="logo">

            <img
                src="assets/lostlink-logo.png"
                alt="LostLink Logo"
            >

        </a>


        <div class="nav-links">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="search.php">
                Cari Barang
            </a>

            <a href="my_reports.php">
                Laporan Saya
            </a>

            <a href="profile.php">
                Profil
            </a>

            <a href="logout.php" class="logout">
                Log Keluar
            </a>

        </div>

    </nav>


    <!-- =====================================================
         MAIN
    ===================================================== -->

    <div class="container">


        <!-- PROFILE HEADER -->

        <div class="profile-header">

            <h1>
                Profil Saya
            </h1>

            <p>
                Urus maklumat akaun dan lihat aktiviti anda
                dalam sistem LostLink.
            </p>

        </div>


        <!-- MESSAGE -->

        <?php

        if ($success != "") {

            echo "
            <div class='success'>
                " . htmlspecialchars($success) . "
            </div>
            ";

        }


        if ($error != "") {

            echo "
            <div class='error'>
                " . htmlspecialchars($error) . "
            </div>
            ";

        }

        ?>


        <!-- =================================================
             STATISTICS
        ================================================= -->

        <div class="stats">


            <div class="stat-card">

                <div class="stat-title">
                    Jumlah Laporan
                </div>

                <div class="stat-number">
                    <?php echo $total_reports; ?>
                </div>

            </div>


            <div class="stat-card">

                <div class="stat-title">
                    Barang Hilang
                </div>

                <div class="stat-number">
                    <?php echo $total_lost; ?>
                </div>

            </div>


            <div class="stat-card">

                <div class="stat-title">
                    Barang Dijumpai
                </div>

                <div class="stat-number">
                    <?php echo $total_found; ?>
                </div>

            </div>


            <div class="stat-card">

                <div class="stat-title">
                    Tuntutan
                </div>

                <div class="stat-number">
                    <?php echo $total_claims; ?>
                </div>

            </div>


        </div>


        <!-- =================================================
             MAKLUMAT AKAUN
        ================================================= -->

        <div class="card">

            <h2>
                Maklumat Akaun
            </h2>


            <div class="account-info">


                <div class="info-box">

                    <div class="info-label">
                        ID Pengguna
                    </div>

                    <div class="info-value">
                        #<?php echo $user['user_id']; ?>
                    </div>

                </div>


                <div class="info-box">

                    <div class="info-label">
                        Peranan
                    </div>

                    <div class="info-value">

                        <?php

                        if ($user['role'] == "admin") {

                            echo "Admin";

                        } else {

                            echo "Pelajar";

                        }

                        ?>

                    </div>

                </div>


                <div class="info-box">

                    <div class="info-label">
                        Tarikh Daftar
                    </div>

                    <div class="info-value">
                        <?php echo htmlspecialchars($user['created_at']); ?>
                    </div>

                </div>


                <div class="info-box">

                    <div class="info-label">
                        Status Akaun
                    </div>

                    <div class="info-value">
                        Aktif
                    </div>

                </div>


            </div>

        </div>


        <!-- =================================================
             EDIT PROFILE
        ================================================= -->

        <div class="card">

            <h2>
                Edit Maklumat Profil
            </h2>


            <form method="POST">


                <div class="form-group">

                    <label>
                        Nama Penuh
                    </label>

                    <input
                        type="text"
                        name="name"
                        value="<?php echo htmlspecialchars($user['name']); ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        No. Matrik
                    </label>

                    <input
                        type="text"
                        name="matric_no"
                        value="<?php echo htmlspecialchars($user['matric_no']); ?>"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Email
                    </label>

                    <input
                        type="email"
                        name="email"
                        value="<?php echo htmlspecialchars($user['email']); ?>"
                        required
                    >

                </div>


                <button
                    type="submit"
                    name="update_profile"
                    class="btn btn-primary"
                >
                    Simpan Perubahan
                </button>


            </form>

        </div>


        <!-- =================================================
             CHANGE PASSWORD
        ================================================= -->

        <div class="card">

            <h2>
                Tukar Password
            </h2>


            <form method="POST">


                <div class="form-group">

                    <label>
                        Password Semasa
                    </label>

                    <input
                        type="password"
                        name="current_password"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Password Baru
                    </label>

                    <input
                        type="password"
                        name="new_password"
                        required
                    >

                    <div class="help-text">
                        Minimum 6 aksara.
                    </div>

                </div>


                <div class="form-group">

                    <label>
                        Sahkan Password Baru
                    </label>

                    <input
                        type="password"
                        name="confirm_password"
                        required
                    >

                </div>


                <button
                    type="submit"
                    name="change_password"
                    class="btn btn-primary"
                >
                    Tukar Password
                </button>


            </form>

        </div>


        <!-- =================================================
             BACK
        ================================================= -->

        <a
            href="dashboard.php"
            class="btn btn-secondary"
        >
            Kembali ke Dashboard
        </a>


    </div>


</body>

</html>