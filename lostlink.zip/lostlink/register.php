<?php

session_start();
include "config.php";

$message = "";

if (isset($_POST['register'])) {

    $name = $_POST['name'];
    $matric_no = $_POST['matric_no'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password != $confirm_password) {

        $message = "Password tidak sepadan.";

    } else {

        $check = $mysqli->query("SELECT * FROM users WHERE email='$email'");

        if ($check->num_rows > 0) {

            $message = "Email telah digunakan.";

        } else {

            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $sql = "INSERT INTO users 
                    (name, matric_no, email, password, role)
                    VALUES
                    ('$name', '$matric_no', '$email', '$hashed_password', 'student')";

            if ($mysqli->query($sql)) {

                header("Location: login.php?registered=1");
                exit;

            } else {

                $message = "Pendaftaran gagal.";

            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="ms">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Daftar - LostLink</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    background: #eef5ff;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* REGISTER BOX */

.register-box {
    background: white;
    width: 450px;
    padding: 35px;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

/* LOGO */

.logo {
    text-align: center;
    margin-bottom: 10px;
}

.logo img {
    width: 180px;
    height: auto;
    display: block;
    margin: auto;
}

/* SUBTITLE */

.subtitle {
    text-align: center;
    color: #666;
    margin-bottom: 25px;
}

/* INPUT */

input {
    width: 100%;
    padding: 13px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 14px;
    outline: none;
}

input:focus {
    border-color: #2563eb;
}

/* BUTTON */

button {
    width: 100%;
    padding: 13px;
    border: none;
    background: #2563eb;
    color: white;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background: #1d4ed8;
}

/* MESSAGE */

.message {
    background: #fee2e2;
    color: #b91c1c;
    padding: 10px;
    border-radius: 7px;
    margin-bottom: 15px;
    text-align: center;
}

/* LOGIN */

.login {
    text-align: center;
    margin-top: 20px;
    color: #555;
}

.login a {
    color: #2563eb;
    text-decoration: none;
    font-weight: bold;
}

.login a:hover {
    text-decoration: underline;
}

/* MOBILE */

@media(max-width: 500px) {

    .register-box {
        width: 90%;
        padding: 25px;
    }

    .logo img {
        width: 150px;
    }

}

</style>

</head>

<body>

<div class="register-box">

    <!-- LOGO -->
    <div class="logo">
        <img src="assets/lostlink-logo.png" alt="LostLink Logo">
    </div>

    <div class="subtitle">
        Daftar Akaun Pelajar
    </div>


    <?php

    if ($message != "") {
        echo "<div class='message'>$message</div>";
    }

    ?>


    <form method="POST">

        <input 
            type="text" 
            name="name" 
            placeholder="Nama penuh" 
            required
        >

        <input 
            type="text" 
            name="matric_no" 
            placeholder="No. Matrik" 
            required
        >

        <input 
            type="email" 
            name="email" 
            placeholder="Email" 
            required
        >

        <input 
            type="password" 
            name="password" 
            placeholder="Password" 
            required
        >

        <input 
            type="password" 
            name="confirm_password" 
            placeholder="Sahkan password" 
            required
        >

        <button type="submit" name="register">
            Daftar Akaun
        </button>

    </form>


    <div class="login">

        Sudah mempunyai akaun?

        <a href="login.php">
            Log Masuk
        </a>

    </div>

</div>

</body>

</html>