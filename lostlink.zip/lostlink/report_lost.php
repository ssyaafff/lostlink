<?php

session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {

    header("Location: login.php");
    exit;

}

$user_id = $_SESSION['user_id'];

$message = "";
$message_type = "";


if (isset($_POST['submit_report'])) {

    $item_name = $_POST['item_name'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $item_date = $_POST['item_date'];

    $image_name = "";


    /* =========================
       ESCAPE DATA
       ========================= */

    $item_name = $mysqli->real_escape_string($item_name);
    $category = $mysqli->real_escape_string($category);
    $description = $mysqli->real_escape_string($description);
    $location = $mysqli->real_escape_string($location);
    $item_date = $mysqli->real_escape_string($item_date);


    /* =========================
       CHECK IMAGE
       ========================= */

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {

        $file_name = $_FILES['image']['name'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];

        $file_extension = strtolower(
            pathinfo($file_name, PATHINFO_EXTENSION)
        );


        $allowed_extensions = array(
            "jpg",
            "jpeg",
            "png"
        );


        if (!in_array($file_extension, $allowed_extensions)) {

            $message = "Format gambar tidak dibenarkan. Sila gunakan JPG, JPEG atau PNG.";
            $message_type = "error";

        } elseif ($file_size > 5000000) {

            $message = "Saiz gambar terlalu besar. Maksimum 5MB.";
            $message_type = "error";

        } else {

            $new_file_name = time() . "_" . uniqid() . "." . $file_extension;

            $upload_folder = "uploads/items/";

            $upload_path = $upload_folder . $new_file_name;


            if (move_uploaded_file($file_tmp, $upload_path)) {

                $image_name = $new_file_name;

            } else {

                $message = "Gambar gagal dimuat naik.";
                $message_type = "error";

            }

        }

    }


    /* =========================
       INSERT REPORT
       ========================= */

    if ($message == "") {

        $sql = "INSERT INTO items
                (user_id, item_type, item_name, category, description, location, item_date, image, status)
                VALUES
                ('$user_id', 'Lost', '$item_name', '$category', '$description', '$location', '$item_date', '$image_name', 'Pending')";


        if ($mysqli->query($sql)) {

            header("Location: my_reports.php?success=lost");
            exit;

        } else {

            $message = "Laporan gagal dihantar.";
            $message_type = "error";

        }

    }

}

?>

<!DOCTYPE html>
<html lang="ms">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Lapor Barang Hilang - LostLink</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #f5f7fa;
    color: #222;
}


/* =========================
   NAVBAR
   ========================= */

header {
    background: white;
    padding: 15px 7%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
}

.logo img {
    width: 145px;
    height: auto;
    display: block;
}

nav {
    display: flex;
    align-items: center;
    gap: 25px;
}

nav a {
    text-decoration: none;
    color: #333;
    font-size: 15px;
}

nav a:hover {
    color: #2563eb;
}

.logout {
    background: #2563eb;
    color: white !important;
    padding: 10px 18px;
    border-radius: 8px;
}


/* =========================
   CONTAINER
   ========================= */

.container {
    width: 90%;
    max-width: 800px;
    margin: 40px auto;
}


/* =========================
   FORM BOX
   ========================= */

.form-box {
    background: white;
    padding: 35px;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.06);
}

.form-title {
    margin-bottom: 8px;
    color: #1e3a8a;
    font-size: 28px;
}

.form-description {
    color: #666;
    margin-bottom: 30px;
    line-height: 1.5;
}


/* =========================
   MESSAGE
   ========================= */

.message {
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
}

.error {
    background: #fee2e2;
    color: #b91c1c;
}


/* =========================
   FORM
   ========================= */

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: #333;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 13px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 14px;
    outline: none;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: #2563eb;
}

.form-group textarea {
    min-height: 120px;
    resize: vertical;
}

.form-group small {
    display: block;
    color: #777;
    margin-top: 6px;
}


/* =========================
   BUTTONS
   ========================= */

.form-buttons {
    display: flex;
    gap: 12px;
    margin-top: 25px;
}

.submit-btn {
    flex: 1;
    padding: 13px;
    border: none;
    border-radius: 8px;
    background: #2563eb;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

.submit-btn:hover {
    background: #1d4ed8;
}

.cancel-btn {
    flex: 1;
    padding: 13px;
    border-radius: 8px;
    background: #e5e7eb;
    color: #333;
    text-align: center;
    text-decoration: none;
}

.cancel-btn:hover {
    background: #d1d5db;
}


/* =========================
   FOOTER
   ========================= */

footer {
    background: #111827;
    color: white;
    text-align: center;
    padding: 25px;
    margin-top: 50px;
}


/* =========================
   MOBILE
   ========================= */

@media(max-width: 700px) {

    header {
        padding: 15px 5%;
    }

    nav {
        gap: 10px;
    }

    nav a {
        font-size: 13px;
    }

    .container {
        width: 92%;
    }

    .form-box {
        padding: 25px;
    }

    .form-buttons {
        flex-direction: column;
    }

}

</style>

</head>

<body>


<!-- =========================
     NAVBAR
     ========================= -->

<header>

    <a href="dashboard.php" class="logo">

        <img src="assets/lostlink-logo.png" alt="LostLink Logo">

    </a>


    <nav>

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="search.php">
            Cari Barang
        </a>

        <a href="my_reports.php">
            Laporan Saya
        </a>

        <a href="profile.php">
            Profil
        </a>

        <a href="logout.php" class="logout">
            Log Keluar
        </a>

    </nav>

</header>


<!-- =========================
     MAIN
     ========================= -->

<div class="container">

    <div class="form-box">

        <h1 class="form-title">
            Laporan Barang Hilang
        </h1>

        <p class="form-description">
            Sila isi maklumat barang yang telah hilang.
            Maklumat yang lengkap dapat membantu pelajar lain
            mengenal pasti barang anda.
        </p>


        <?php

        if ($message != "") {

            echo "
            <div class='message $message_type'>
                $message
            </div>
            ";

        }

        ?>


        <form method="POST" enctype="multipart/form-data">


            <!-- NAMA BARANG -->

            <div class="form-group">

                <label>
                    Nama Barang
                </label>

                <input
                    type="text"
                    name="item_name"
                    placeholder="Contoh: Dompet hitam"
                    required
                >

            </div>


            <!-- KATEGORI -->

            <div class="form-group">

                <label>
                    Kategori
                </label>

                <select name="category" required>

                    <option value="">
                        -- Pilih Kategori --
                    </option>

                    <option value="Pakaian">
                        Pakaian
                    </option>

                    <option value="Kasut">
                        Kasut
                    </option>

                    <option value="Dompet">
                        Dompet
                    </option>

                    <option value="Kunci">
                        Kunci
                    </option>

                    <option value="Kad">
                        Kad / Kad Matrik
                    </option>

                    <option value="Elektronik">
                        Elektronik
                    </option>

                    <option value="Buku">
                        Buku
                    </option>

                    <option value="Aksesori">
                        Aksesori
                    </option>

                    <option value="Lain-lain">
                        Lain-lain
                    </option>

                </select>

            </div>


            <!-- LOKASI -->

            <div class="form-group">

                <label>
                    Lokasi Terakhir Dilihat
                </label>

                <input
                    type="text"
                    name="location"
                    placeholder="Contoh: Blok A, Dewan Makan, Surau"
                    required
                >

            </div>


            <!-- TARIKH -->

            <div class="form-group">

                <label>
                    Tarikh Barang Hilang
                </label>

                <input
                    type="date"
                    name="item_date"
                    required
                >

            </div>


            <!-- DESCRIPTION -->

            <div class="form-group">

                <label>
                    Penerangan Barang
                </label>

                <textarea
                    name="description"
                    placeholder="Terangkan warna, jenama, ciri-ciri atau maklumat lain yang berkaitan..."
                    required
                ></textarea>

            </div>


            <!-- IMAGE -->

            <div class="form-group">

                <label>
                    Gambar Barang
                </label>

                <input
                    type="file"
                    name="image"
                    accept=".jpg,.jpeg,.png"
                >

                <small>
                    Format: JPG, JPEG atau PNG. Maksimum 5MB.
                </small>

            </div>


            <!-- BUTTON -->

            <div class="form-buttons">

                <a href="dashboard.php" class="cancel-btn">
                    Batal
                </a>

                <button
                    type="submit"
                    name="submit_report"
                    class="submit-btn"
                >
                    Hantar Laporan
                </button>

            </div>


        </form>

    </div>

</div>


<footer>

    © 2026 LostLink | Sistem Pengurusan Barang Hilang dan Dijumpai

</footer>


</body>

</html>