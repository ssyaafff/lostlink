<?php

session_start();
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

/* =========================
   SEARCH DATA
========================= */

$keyword = "";
$category = "";
$item_type = "";
$location = "";

$where = "WHERE status != 'Closed'";

if (isset($_GET['keyword']) && $_GET['keyword'] != "") {
    $keyword = $mysqli->real_escape_string($_GET['keyword']);

    $where .= " AND (
        item_name LIKE '%$keyword%'
        OR description LIKE '%$keyword%'
    )";
}

if (isset($_GET['category']) && $_GET['category'] != "") {
    $category = $mysqli->real_escape_string($_GET['category']);

    $where .= " AND category = '$category'";
}

if (isset($_GET['item_type']) && $_GET['item_type'] != "") {
    $item_type = $mysqli->real_escape_string($_GET['item_type']);

    $where .= " AND item_type = '$item_type'";
}

if (isset($_GET['location']) && $_GET['location'] != "") {
    $location = $mysqli->real_escape_string($_GET['location']);

    $where .= " AND location LIKE '%$location%'";
}

$sql = "
    SELECT items.*, users.name
    FROM items
    INNER JOIN users ON items.user_id = users.user_id
    $where
    ORDER BY items.created_at DESC
";

$result = $mysqli->query($sql);

?>

<!DOCTYPE html>
<html lang="ms">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Cari Barang - LostLink</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f5f7fa;
            color: #1f2937;
        }

        /* =========================
           NAVBAR
        ========================= */

        .navbar {
            width: 100%;
            min-height: 75px;
            background: #ffffff;

            display: flex;
            align-items: center;

            padding: 0 6%;

            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);

            position: relative;
            z-index: 100;
        }

        .logo {
            display: flex;
            align-items: center;

            text-decoration: none;

            flex-shrink: 0;
        }

        .logo img {
            width: 150px;
            height: auto;

            display: block;
        }

        .nav-links {
            margin-left: auto;

            display: flex;
            align-items: center;
            justify-content: flex-end;

            gap: 20px;

            white-space: nowrap;
        }

        .nav-links a {
            text-decoration: none;

            color: #374151;

            font-size: 14px;
            font-weight: bold;

            display: flex;
            align-items: center;

            padding: 8px 0;
        }

        .nav-links a:hover {
            color: #2563eb;
        }

        .nav-links .logout {
            background: #2563eb;

            color: white !important;

            padding: 10px 17px;

            border-radius: 8px;
        }

        .nav-links .logout:hover {
            background: #1d4ed8;

            color: white !important;
        }


        /* =========================
           PAGE
        ========================= */

        .container {
            width: 86%;
            max-width: 1200px;

            margin: 40px auto;
        }

        .page-header {
            margin-bottom: 25px;
        }

        .page-header h1 {
            font-size: 30px;

            color: #111827;

            margin-bottom: 8px;
        }

        .page-header p {
            color: #6b7280;

            font-size: 15px;
        }


        /* =========================
           SEARCH BOX
        ========================= */

        .search-box {
            background: white;

            padding: 25px;

            border-radius: 15px;

            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);

            margin-bottom: 30px;
        }

        .search-row {
            display: grid;

            grid-template-columns: 2fr 1fr 1fr;

            gap: 15px;

            margin-bottom: 15px;
        }

        .search-row:last-child {
            margin-bottom: 0;
        }

        .input-group {
            display: flex;

            flex-direction: column;
        }

        .input-group label {
            font-size: 13px;

            font-weight: bold;

            color: #374151;

            margin-bottom: 7px;
        }

        input,
        select {
            width: 100%;

            padding: 12px 13px;

            border: 1px solid #d1d5db;

            border-radius: 8px;

            font-size: 14px;

            outline: none;

            background: white;
        }

        input:focus,
        select:focus {
            border-color: #2563eb;
        }

        .button-row {
            display: flex;

            gap: 10px;

            align-items: flex-end;
        }

        .btn-search {
            border: none;

            background: #2563eb;

            color: white;

            padding: 12px 25px;

            border-radius: 8px;

            cursor: pointer;

            font-weight: bold;

            font-size: 14px;
        }

        .btn-search:hover {
            background: #1d4ed8;
        }

        .btn-reset {
            text-decoration: none;

            background: #e5e7eb;

            color: #374151;

            padding: 12px 20px;

            border-radius: 8px;

            font-size: 14px;

            font-weight: bold;
        }

        .btn-reset:hover {
            background: #d1d5db;
        }


        /* =========================
           RESULT HEADER
        ========================= */

        .result-header {
            display: flex;

            justify-content: space-between;

            align-items: center;

            margin-bottom: 18px;
        }

        .result-header h2 {
            font-size: 21px;

            color: #111827;
        }

        .result-count {
            color: #6b7280;

            font-size: 14px;
        }


        /* =========================
           ITEM GRID
        ========================= */

        .item-grid {
            display: grid;

            grid-template-columns: repeat(3, 1fr);

            gap: 22px;
        }

        .item-card {
            background: white;

            border-radius: 15px;

            overflow: hidden;

            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);

            transition: 0.2s;
        }

        .item-card:hover {
            transform: translateY(-3px);

            box-shadow: 0 7px 20px rgba(0, 0, 0, 0.1);
        }

        .item-image {
            width: 100%;

            height: 190px;

            background: #eef2f7;

            display: flex;

            justify-content: center;

            align-items: center;

            overflow: hidden;
        }

        .item-image img {
            width: 100%;

            height: 100%;

            object-fit: cover;
        }

        .no-image {
            color: #9ca3af;

            font-size: 14px;
        }

        .item-content {
            padding: 18px;
        }


        /* =========================
           BADGES
        ========================= */

        .badges {
            display: flex;

            gap: 7px;

            flex-wrap: wrap;

            margin-bottom: 10px;
        }

        .badge {
            padding: 5px 9px;

            border-radius: 20px;

            font-size: 11px;

            font-weight: bold;
        }

        .badge-lost {
            background: #fee2e2;

            color: #b91c1c;
        }

        .badge-found {
            background: #dcfce7;

            color: #15803d;
        }

        .badge-pending {
            background: #fef3c7;

            color: #92400e;
        }

        .badge-claimed {
            background: #dbeafe;

            color: #1d4ed8;
        }

        .badge-closed {
            background: #e5e7eb;

            color: #4b5563;
        }


        /* =========================
           ITEM INFO
        ========================= */

        .item-content h3 {
            font-size: 18px;

            color: #111827;

            margin-bottom: 10px;
        }

        .item-info {
            margin-bottom: 14px;
        }

        .item-info p {
            color: #6b7280;

            font-size: 13px;

            margin-bottom: 6px;
        }

        .detail-btn {
            display: block;

            text-align: center;

            text-decoration: none;

            background: #2563eb;

            color: white;

            padding: 10px;

            border-radius: 8px;

            font-size: 13px;

            font-weight: bold;
        }

        .detail-btn:hover {
            background: #1d4ed8;
        }


        /* =========================
           NO RESULT
        ========================= */

        .no-result {
            background: white;

            padding: 50px 20px;

            border-radius: 15px;

            text-align: center;

            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        .no-result h3 {
            margin-bottom: 8px;

            color: #374151;
        }

        .no-result p {
            color: #6b7280;

            font-size: 14px;
        }


        /* =========================
           TABLET
        ========================= */

        @media (max-width: 1000px) {

            .navbar {
                padding: 0 4%;
            }

            .nav-links {
                gap: 14px;
            }

            .nav-links a {
                font-size: 13px;
            }

            .item-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .search-row {
                grid-template-columns: 1fr 1fr;
            }

        }


        /* =========================
           MOBILE
        ========================= */

        @media (max-width: 750px) {

            .navbar {
                min-height: 75px;

                height: auto;

                padding: 15px 5%;

                flex-direction: column;

                gap: 15px;
            }

            .logo {
                justify-content: center;

                width: 100%;
            }

            .logo img {
                width: 145px;
            }

            .nav-links {
                width: 100%;

                margin-left: 0;

                display: flex;

                align-items: center;

                justify-content: center;

                flex-wrap: wrap;

                gap: 10px 15px;

                white-space: normal;
            }

            .nav-links a {
                font-size: 13px;

                padding: 6px 0;
            }

            .nav-links .logout {
                padding: 9px 15px;
            }

            .container {
                width: 92%;

                margin: 25px auto;
            }

            .search-row {
                grid-template-columns: 1fr;
            }

            .button-row {
                align-items: stretch;

                flex-direction: column;
            }

            .btn-search,
            .btn-reset {
                width: 100%;

                text-align: center;
            }

            .item-grid {
                grid-template-columns: 1fr;
            }

            .result-header {
                flex-direction: column;

                align-items: flex-start;

                gap: 5px;
            }

        }


        /* =========================
           SMALL PHONE
        ========================= */

        @media (max-width: 450px) {

            .navbar {
                padding: 14px 4%;
            }

            .nav-links {
                gap: 8px 12px;
            }

            .nav-links a {
                font-size: 12px;
            }

            .nav-links .logout {
                padding: 8px 12px;
            }

            .search-box {
                padding: 18px;
            }

            .page-header h1 {
                font-size: 25px;
            }

        }

    </style>

</head>

<body>


<!-- =========================
     NAVBAR
========================= -->

<div class="navbar">

    <a href="dashboard.php" class="logo">

        <img
            src="assets/lostlink-logo.png"
            alt="LostLink Logo"
        >

    </a>


    <div class="nav-links">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="search.php">
            Cari Barang
        </a>

        <a href="my_reports.php">
            Laporan Saya
        </a>

        <a href="profile.php">
            Profil
        </a>

        <a href="logout.php" class="logout">
            Log Keluar
        </a>

    </div>

</div>


<!-- =========================
     MAIN CONTENT
========================= -->

<div class="container">

    <div class="page-header">

        <h1>
            Cari Barang
        </h1>

        <p>
            Cari barang yang hilang atau dijumpai berdasarkan maklumat yang tersedia.
        </p>

    </div>


    <!-- =========================
         SEARCH FORM
    ========================= -->

    <div class="search-box">

        <form method="GET" action="search.php">

            <div class="search-row">

                <div class="input-group">

                    <label>
                        Kata Kunci
                    </label>

                    <input
                        type="text"
                        name="keyword"
                        placeholder="Contoh: dompet, kasut, charger..."
                        value="<?php echo htmlspecialchars($keyword); ?>"
                    >

                </div>


                <div class="input-group">

                    <label>
                        Kategori
                    </label>

                    <select name="category">

                        <option value="">
                            Semua Kategori
                        </option>

                        <option value="Pakaian"
                        <?php
                        if ($category == "Pakaian") {
                            echo "selected";
                        }
                        ?>>
                            Pakaian
                        </option>

                        <option value="Kasut"
                        <?php
                        if ($category == "Kasut") {
                            echo "selected";
                        }
                        ?>>
                            Kasut
                        </option>

                        <option value="Dompet"
                        <?php
                        if ($category == "Dompet") {
                            echo "selected";
                        }
                        ?>>
                            Dompet
                        </option>

                        <option value="Kunci"
                        <?php
                        if ($category == "Kunci") {
                            echo "selected";
                        }
                        ?>>
                            Kunci
                        </option>

                        <option value="Kad"
                        <?php
                        if ($category == "Kad") {
                            echo "selected";
                        }
                        ?>>
                            Kad
                        </option>

                        <option value="Elektronik"
                        <?php
                        if ($category == "Elektronik") {
                            echo "selected";
                        }
                        ?>>
                            Elektronik
                        </option>

                        <option value="Buku"
                        <?php
                        if ($category == "Buku") {
                            echo "selected";
                        }
                        ?>>
                            Buku
                        </option>

                        <option value="Aksesori"
                        <?php
                        if ($category == "Aksesori") {
                            echo "selected";
                        }
                        ?>>
                            Aksesori
                        </option>

                        <option value="Lain-lain"
                        <?php
                        if ($category == "Lain-lain") {
                            echo "selected";
                        }
                        ?>>
                            Lain-lain
                        </option>

                    </select>

                </div>


                <div class="input-group">

                    <label>
                        Jenis Laporan
                    </label>

                    <select name="item_type">

                        <option value="">
                            Semua
                        </option>

                        <option value="Lost"
                        <?php
                        if ($item_type == "Lost") {
                            echo "selected";
                        }
                        ?>>
                            Barang Hilang
                        </option>

                        <option value="Found"
                        <?php
                        if ($item_type == "Found") {
                            echo "selected";
                        }
                        ?>>
                            Barang Dijumpai
                        </option>

                    </select>

                </div>

            </div>


            <div class="search-row">

                <div class="input-group">

                    <label>
                        Lokasi
                    </label>

                    <input
                        type="text"
                        name="location"
                        placeholder="Contoh: Blok A, Dewan Makan..."
                        value="<?php echo htmlspecialchars($location); ?>"
                    >

                </div>


                <div class="button-row">

                    <button
                        type="submit"
                        class="btn-search"
                    >
                        🔍 Cari Barang
                    </button>

                    <a
                        href="search.php"
                        class="btn-reset"
                    >
                        Reset
                    </a>

                </div>

            </div>

        </form>

    </div>


    <!-- =========================
         RESULT
    ========================= -->

    <div class="result-header">

        <h2>
            Senarai Barang
        </h2>

        <div class="result-count">

            <?php

            echo $result->num_rows;

            ?>

            rekod dijumpai

        </div>

    </div>


    <?php

    if ($result->num_rows > 0) {

        ?>

        <div class="item-grid">

        <?php

        while ($row = $result->fetch_assoc()) {

            ?>

            <div class="item-card">


                <!-- IMAGE -->

                <div class="item-image">

                    <?php

                    if (!empty($row['image'])) {

                        ?>

                        <img
                            src="uploads/items/<?php echo htmlspecialchars($row['image']); ?>"
                            alt="Gambar barang"
                        >

                        <?php

                    } else {

                        ?>

                        <div class="no-image">
                            Tiada gambar
                        </div>

                        <?php

                    }

                    ?>

                </div>


                <!-- CONTENT -->

                <div class="item-content">


                    <div class="badges">

                        <?php

                        if ($row['item_type'] == "Lost") {

                            ?>

                            <span class="badge badge-lost">
                                BARANG HILANG
                            </span>

                            <?php

                        } else {

                            ?>

                            <span class="badge badge-found">
                                BARANG DIJUMPAI
                            </span>

                            <?php

                        }


                        if ($row['status'] == "Pending") {

                            ?>

                            <span class="badge badge-pending">
                                Pending
                            </span>

                            <?php

                        } elseif ($row['status'] == "Found") {

                            ?>

                            <span class="badge badge-found">
                                Dijumpai
                            </span>

                            <?php

                        } elseif ($row['status'] == "Claimed") {

                            ?>

                            <span class="badge badge-claimed">
                                Dituntut
                            </span>

                            <?php

                        } else {

                            ?>

                            <span class="badge badge-closed">
                                Ditutup
                            </span>

                            <?php

                        }

                        ?>

                    </div>


                    <h3>

                        <?php

                        echo htmlspecialchars($row['item_name']);

                        ?>

                    </h3>


                    <div class="item-info">

                        <p>
                            📁
                            <?php
                            echo htmlspecialchars($row['category']);
                            ?>
                        </p>

                        <p>
                            📍
                            <?php
                            echo htmlspecialchars($row['location']);
                            ?>
                        </p>

                        <p>
                            📅
                            <?php
                            echo date(
                                "d/m/Y",
                                strtotime($row['item_date'])
                            );
                            ?>
                        </p>

                    </div>


                    <a
                        href="item_details.php?id=<?php echo $row['item_id']; ?>"
                        class="detail-btn"
                    >
                        Lihat Butiran
                    </a>

                </div>

            </div>

            <?php

        }

        ?>

        </div>

        <?php

    } else {

        ?>

        <div class="no-result">

            <h3>
                Tiada barang dijumpai
            </h3>

            <p>
                Cuba gunakan kata kunci atau pilihan kategori yang berbeza.
            </p>

        </div>

        <?php

    }

    ?>

</div>

</body>

</html>